import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmplAuthComponent } from './empl-auth.component';

describe('EmplAuthComponent', () => {
  let component: EmplAuthComponent;
  let fixture: ComponentFixture<EmplAuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmplAuthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmplAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
