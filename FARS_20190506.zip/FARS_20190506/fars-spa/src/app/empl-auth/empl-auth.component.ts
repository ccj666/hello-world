import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MDLEmpl } from '../_Model/MDLEmpl';
import { MDLAuth } from '../_Model/MDLAuth';
import { MDLSyst } from '../_Model/MDLSyst';
import { AuthService } from '../_Service/auth.service';

@Component({
  selector: 'app-empl-auth',
  templateUrl: './empl-auth.component.html',
  styleUrls: ['./empl-auth.component.css']
})
export class EmplAuthComponent implements OnInit {
  @Input() Empl: MDLEmpl;
  @Input() Syst: MDLSyst

  Auth: MDLAuth = new MDLAuth();
  AuthForm: FormGroup;

  AreaList = [{ Text: 'TW', Value: 'TW' }, { Text: 'HK', Value: 'HK' }, { Text: 'SG', Value: 'SG' }, { Text: 'VN', Value: 'VN' }];

  AuthList: MDLAuth[];

  constructor( 
    private AuthService: AuthService,
    private fb: FormBuilder ) { 
      this.AuthForm = this.createFormGroup();
    }

  createFormGroup() {
    return this.fb.group(this.Auth);
    /*return new FormGroup({
      AcctId: new FormControl(),
      AcctArea: new FormControl(),
      AcctRole: new FormControl(),
      ActiveDate: new FormControl(),
      DeactiveDate: new FormControl(),
      Remark: new FormControl()
    });*/
  }

  ngOnInit() {
  }

  getAuthList(EmplId : string, SystId : number): void {
    //this.MsgService.add('getAuthListByEmplSyst()');
    
    this.AuthForm = this.createFormGroup();

    this.AuthService.getAuthListByEmplSyst(EmplId, SystId)
      .subscribe(AuthList => this.AuthList = AuthList);
  }

}
