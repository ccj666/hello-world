import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

import { MDLAuth } from '../_Model/MDLAuth';
import { AuthService } from '../_Service/auth.service';
import { NotDateValidator } from '../_Directive/not-date-validator.directive';
import { TwoDatesLargeToSmallValidator } from '../_Directive/two-dates-large-to-small-validator.directive';

@Component({
  selector: 'app-auth-editor',
  templateUrl: './auth-editor.component.html',
  styleUrls: ['./auth-editor.component.css']
})
export class AuthEditorComponent implements OnInit {
  /*@Input() Empl: MDLEmpl;
  @Input() Syst: MDLSyst;*/
  @Output() IsCancelled = new EventEmitter<boolean>();
  @Output() IsDone = new EventEmitter<boolean>();

  AuthForm: FormGroup;

  AreaList = [{ Text: 'TW', Value: 'TW' }, { Text: 'HK', Value: 'HK' }, { Text: 'SG', Value: 'SG' }, { Text: 'VN', Value: 'VN' }];

  Auth: MDLAuth;
  AuthList: MDLAuth[];

  constructor( 
    private AuthService: AuthService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.BindAuthForm(null);  // new MDLAuth
  }

  BindAuthForm(Auth: MDLAuth): void {
    if (Auth) {
      const dp = new DatePipe(navigator.language);
      this.AuthForm = this.fb.group({
        AcctArea: Auth.AcctArea,
        AcctId: Auth.AcctId,
        AcctRole: Auth.AcctRole,
        ActiveDate: new FormControl(dp.transform(Auth.ActiveDate, 'yyyy/M/d'), NotDateValidator),
        DeactiveDate: new FormControl(dp.transform(Auth.DeactiveDate, 'yyyy/M/d'), NotDateValidator),
        Remark: Auth.Remark
      }, { validators: TwoDatesLargeToSmallValidator });
    }

    //
    this.Auth = Auth;
  }

  Cancel(): void {
    //this.BindAuthForm(null);
    this.Auth = null;
    this.IsCancelled.emit(true);
  }

  Delete(): void {
    //this.BindAuthForm(null);
    if(confirm("您確定要刪除這個權限設定?")) {
      this.AuthService.deleteAuth(this.Auth.Id)
        .subscribe(_ => {
            this.Auth = null;
            this.IsDone.emit(true);
          }
        );
    }
  }

  onSubmit(): void {
    // These values are still referenced by our form. If we just copy that reference and modify the data elsewhere, the form will be impacted, as well. This can cause weird side-effects.
    // So, we need to create a copy of the data
    const AuthFormValue: MDLAuth = Object.assign({}, this.AuthForm.value);

    // 因為Object.assign不會Clone下列property, 所以需要另外提供給WebApi.
    AuthFormValue.Status = '1';
    AuthFormValue.EmplId = this.Auth.EmplId;
    AuthFormValue.SystId = this.Auth.SystId;
    AuthFormValue.UpdateUser = '';

    // 
    if (this.Auth.Id) {  // edit
      AuthFormValue.Id = this.Auth.Id;
      this.AuthService.updateAuth(AuthFormValue)
      .subscribe(Auth => {
        if (Auth) {
          this.Auth = null;
          this.IsDone.emit(true);
        }
      });
    }
    else {  // add new
      this.AuthService.addAuth(AuthFormValue)
        .subscribe(Auth => {
          if (Auth) {
            this.Auth = null;
            this.IsDone.emit(true);
          }
        });
    }
  }

}
