import { Component, OnInit } from '@angular/core';

import { MDLCmpr } from '../_Model/MDLCmpr';
import { CmprService } from '../_Service/cmpr.service';

@Component({
  selector: 'app-cmpr',
  templateUrl: './cmpr.component.html',
  styleUrls: ['./cmpr.component.css']
})
export class CmprComponent implements OnInit {

  CmprList: MDLCmpr[];

  constructor(
    private CmprService: CmprService
  ) {}

  ngOnInit() {
    this.getCmprList();
  }

  getCmprList(): void {
    this.CmprService.getCmprList()
      .subscribe(CmprList => this.CmprList = CmprList);
  }
}
