import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmprComponent } from './cmpr.component';

describe('CmprComponent', () => {
  let component: CmprComponent;
  let fixture: ComponentFixture<CmprComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmprComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmprComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
