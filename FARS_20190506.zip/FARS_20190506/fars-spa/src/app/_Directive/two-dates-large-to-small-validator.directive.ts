import { Directive } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';

export const TwoDatesLargeToSmallValidator: ValidatorFn = (control: FormGroup): ValidationErrors | null => {
  const ActiveDate = control.get('ActiveDate');
  const DeactiveDate = control.get('DeactiveDate');

  return new Date(ActiveDate.value) >= new Date(DeactiveDate.value) ? { 'TwoDatesLargeToSmall': true } : null;
};

@Directive({
  selector: '[appTwoDatesLargeToSmallValidator]'
})

export class TwoDatesLargeToSmallValidatorDirective {

  constructor() { }

}

/*@Directive({
  selector: '[appTwoDatesLargeToSmallValidator]',
  providers: [{ provide: NG_VALIDATORS, useExisting: TwoDatesLargeToSmallValidator, multi: true }]
})

export class TwoDatesLargeToSmallValidatorDirective implements Validator {
  validate(control: AbstractControl): ValidationErrors {
    return TwoDatesLargeToSmallValidator(control)
  }
}*/
