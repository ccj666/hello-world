import { TwoDatesLargeToSmallValidatorDirective } from './two-dates-large-to-small-validator.directive';

describe('TwoDatesLargeToSmallValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new TwoDatesLargeToSmallValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
