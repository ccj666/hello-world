import { Directive } from '@angular/core';
import { AbstractControl, FormGroup, NG_VALIDATORS, ValidationErrors, Validator, ValidatorFn, FormControl } from '@angular/forms';

export const NotDateValidator: ValidatorFn = (control: FormControl): ValidationErrors | null => {
  const DateString: string = control.value;
  const dateformat: RegExp = /^\d{4}\/(\d{1}|\d{2})\/(\d{1}|\d{2})$/;
  if (!dateformat.test(DateString)) 
    return { 'NotDate': true };
  else {
    //return Date.parse(DateString) ? null : { 'NotDate': true };

    // 因為 new Date('2019/2/29') 會變成 2019/3/1, 所以必須檢查 Year Month Day
    const arr1: string[] = DateString.split('/');
    const Date1: Date = new Date(DateString);
    if ((Date1.getFullYear() == Number(arr1[0])) && 
        (Date1.getMonth() == Number(arr1[1]) - 1) &&  // month index is 0-based
        (Date1.getDate() == Number(arr1[2])))
      return null;
    else
      return { 'NotDate': true };
  }
};

@Directive({
  selector: '[appNotDateValidator]'
})

export class NotDateValidatorDirective {

  constructor() { }

}

/*@Directive({
  selector: '[appNotDateValidator]',
  providers: [{ provide: NG_VALIDATORS, useExisting: NotDateValidator, multi: true }]
})

export class NotDateValidatorDirective implements Validator {
  validate(control: AbstractControl): ValidationErrors {
    return NotDateValidator(control)
  }
}*/
