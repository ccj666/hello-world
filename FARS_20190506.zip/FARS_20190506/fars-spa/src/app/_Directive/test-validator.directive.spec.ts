import { TestValidatorDirective } from './test-validator.directive';

describe('TestValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new TestValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
