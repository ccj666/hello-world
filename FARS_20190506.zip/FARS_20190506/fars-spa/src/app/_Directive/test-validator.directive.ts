import { Directive } from '@angular/core';

@Directive({
  selector: '[appTestValidator]'
})
export class TestValidatorDirective {

  constructor() { }

}
