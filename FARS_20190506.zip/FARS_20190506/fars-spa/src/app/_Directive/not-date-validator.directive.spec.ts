import { NotDateValidatorDirective } from './not-date-validator.directive';

describe('NotDateValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new NotDateValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
