import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmplSearch2Component } from './empl-search-2.component';

describe('EmplSearch2Component', () => {
  let component: EmplSearch2Component;
  let fixture: ComponentFixture<EmplSearch2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmplSearch2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmplSearch2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
