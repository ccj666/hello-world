import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { Observable, Subject } from 'rxjs';

import {
   debounceTime, distinctUntilChanged, switchMap
 } from 'rxjs/operators';

import { MDLEmpl } from '../_Model/MDLEmpl';
import { EmplService } from '../_Service/empl.service';
import { MDLSyst } from '../_Model/MDLSyst';
import { EmplAuthComponent } from "../empl-auth/empl-auth.component";

@Component({
  selector: 'app-empl-search-2',
  templateUrl: './empl-search-2.component.html',
  styleUrls: ['./empl-search-2.component.css']
})
export class EmplSearch2Component implements OnInit {

  @Input() Syst: MDLSyst;

  EmplList$: Observable<MDLEmpl[]>;
  private SearchTerms = new Subject<string>();

  SelectedEmpl: MDLEmpl;

  @ViewChild(EmplAuthComponent) child: EmplAuthComponent ; 

  constructor(private EmplService: EmplService) {}

  // Push a search term into the observable stream.
  search(term: string): void {
    this.SearchTerms.next(term);
  }

  ngOnInit() {
    this.EmplList$ = this.SearchTerms.pipe(
      // wait 500ms after each keystroke before considering the term
      debounceTime(500),

      // ignore new term if same as previous term
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap((term: string) => this.EmplService.searchEmplList(term)),
    );
  }
 
  onSelect(Empl: MDLEmpl): void {
    this.SelectedEmpl = Empl;
    this.child.getAuthList(Empl.Id, this.Syst.Id);
  }
}
