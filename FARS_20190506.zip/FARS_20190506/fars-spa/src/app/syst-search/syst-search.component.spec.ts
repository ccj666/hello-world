import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystSearchComponent } from './syst-search.component';

describe('SystSearchComponent', () => {
  let component: SystSearchComponent;
  let fixture: ComponentFixture<SystSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
