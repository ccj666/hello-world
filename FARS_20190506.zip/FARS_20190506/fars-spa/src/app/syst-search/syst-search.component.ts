import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { MDLSyst } from '../_Model/MDLSyst';
import { SystService } from '../_Service/syst.service';

@Component({
  selector: 'app-syst-search',
  templateUrl: './syst-search.component.html',
  styleUrls: ['./syst-search.component.css']
})
export class SystSearchComponent implements OnInit {
  @Output() IsSystSelected = new EventEmitter<boolean>();

  SystList$: Observable<MDLSyst[]>;
  private SearchTerms = new Subject<string>();

  SelectedSyst: MDLSyst;  // = new MDLSyst

  constructor(private SystService: SystService) {}

  ngOnInit() {
    this.SystList$ = this.SearchTerms.pipe(
      // wait 500ms after each keystroke before considering the term
      debounceTime(500),

      // ignore new term if same as previous term
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap((term: string) => this.SystService.searchSystList(term)),
    );
  }
 
  // Push a search term into the observable stream.
  search(term: string): void {
    this.SearchTerms.next(term);

    //console.log('SearchTerms:', this.SearchTerms);

    // if searchBox is empty, then clear SelectedSyst
    if (!term.trim()) {
      this.onSelect(null);  // new MDLSyst
    }
  }

  onSelect(Syst: MDLSyst): void {
    if (Syst != this.SelectedSyst) {
      this.SelectedSyst = Syst;
      this.IsSystSelected.emit(true);
    }
  }
}
