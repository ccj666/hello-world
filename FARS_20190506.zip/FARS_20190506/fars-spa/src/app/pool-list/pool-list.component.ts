import { Component, OnInit } from '@angular/core';
import { MDLPool } from '../_Model/MDLPool';
import { PoolService } from '../_Service/pool.service';

@Component({
  selector: 'app-pool-list',
  templateUrl: './pool-list.component.html',
  styleUrls: ['./pool-list.component.css']
})
export class PoolListComponent implements OnInit {

  PoolList: MDLPool[];

  constructor(private PoolService: PoolService) { }

  ngOnInit() {
    this.getPoolList();
  }

  getPoolList(): void {
    this.PoolService.getPoolList()
      .subscribe(PoolList => this.PoolList = PoolList);
  }
}
