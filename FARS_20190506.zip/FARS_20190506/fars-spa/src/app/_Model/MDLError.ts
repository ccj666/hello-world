export class MDLError {
  Code: string;
  Description: string;
}
