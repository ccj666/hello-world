export class MDLEmpl {
  Id: string = '';
  Status: string = '1';
  Name: string = '';
  Email: string = '';
  ADId: string = '';
  Grade: number = 0;
  DeptId: string = '';
  DeptName: string = '';
  JobTitleName: string = '';
  ArriveDate: Date;
  LeaveDate: Date;
  UpdateTime: Date;
  UpdateUser: string = '';
}
