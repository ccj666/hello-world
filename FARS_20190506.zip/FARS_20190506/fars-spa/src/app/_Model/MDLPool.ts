export class MDLPool {
  Id?: number;
  SystCode: string = '';
  AcctArea: string = 'TW';
  AcctId: string = '';
  AcctRole: string = '';
  AcctEmail?: string = '';
  SystId?: number;
  IsAcctArea?: string = '';
  EmplId?: string = '';
  MappingBy?: string = '';
  IsAcctRole?: string = '';
  Remark?: string = '';
  UpdateTime?: Date;
  UpdateUser?: string = '';
}

export class MDLPool_Add {
  SystCode: string = '';
  AcctArea: string = 'TW';
  AcctId: string = '';
  AcctRole1: string = '';
  AcctRole2: string = '';
  AcctRole3: string = '';
  UpdateUser?: string = '';
}
