/* compare Pool with Auth */
export class MDLCmpr {
  Pool_Id: number;
  Pool_SystCode: string = '';
  Pool_AcctArea: string = 'TW';
  Pool_AcctId: string = '';
  Pool_AcctRole: string = '';
  Pool_AcctEmail: string = '';
  Pool_SystId: number;
  Pool_IsAcctArea: string = '';
  Pool_EmplId: string = '';
  Pool_MappingBy: string = '';
  Pool_IsAcctRole: string = '';
  Auth_Id: number;
  Auth_EmplId: string = '';
  Auth_SystId: number;
  Auth_AcctArea: string = 'TW';
  Auth_AcctId: string = '';
  Auth_AcctRole: string = '';
}
