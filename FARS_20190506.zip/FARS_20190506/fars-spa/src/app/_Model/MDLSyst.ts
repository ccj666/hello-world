export class MDLSyst {
  Id: number;
  Status: string = '1';
  Type: string = 'EXT';
  Code: string = '';
  Name: string = '';
  Frequency: string[] = [];
  ContactName: string = '';
  ContactEmail: string = '';
  ContactTel: string = '';
  DisplayOrder: number = 0;
  AuthAnnex: string = '';
  AuthProvide: Date = new Date();
  UpdateTime: Date;
  UpdateUser: string = '';
}
