export class MDLMessage {
  IsError: boolean;
  Text: string;
}
