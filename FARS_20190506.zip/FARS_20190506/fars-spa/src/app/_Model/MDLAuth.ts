export class MDLAuth {
  Id: number;
  Status: string = '1';
  EmplId: string = '';
  SystId: number;
  SystCode: string = '';
  AcctArea: string = 'TW';
  AcctId: string = '';
  AcctRole: string = '';
  ActiveDate: Date = new Date();
  DeactiveDate: Date = new Date('9999/1/1');
  Remark: string = '';
  UpdateTime: Date;
  UpdateUser: string = '';
  EmplName: string = '';
  DeptName: string = '';
  SystName: string = '';
  AuthAnnex: string = '';
  AuthProvide: Date;
}
