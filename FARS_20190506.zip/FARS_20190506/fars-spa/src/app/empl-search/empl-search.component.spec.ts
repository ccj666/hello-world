import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmplSearchComponent } from './empl-search.component';

describe('EmplSearchComponent', () => {
  let component: EmplSearchComponent;
  let fixture: ComponentFixture<EmplSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmplSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmplSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
