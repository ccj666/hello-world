import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { MDLEmpl } from '../_Model/MDLEmpl';
import { EmplService } from '../_Service/empl.service';

@Component({
  selector: 'app-empl-search',
  templateUrl: './empl-search.component.html',
  styleUrls: ['./empl-search.component.css']
})
export class EmplSearchComponent implements OnInit {
  @Output() IsEmplSelected = new EventEmitter<boolean>();

  EmplList$: Observable<MDLEmpl[]>;
  private SearchTerms = new Subject<string>();

  SelectedEmpl: MDLEmpl;  // = new MDLEmpl

  constructor(private EmplService: EmplService) {}

  ngOnInit() {
    this.EmplList$ = this.SearchTerms.pipe(
      // wait 500ms after each keystroke before considering the term
      debounceTime(500),

      // ignore new term if same as previous term
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap((term: string) => this.EmplService.searchEmplList(term)),
    );
  }
 
  // Push a search term into the observable stream.
  search(term: string): void {
    this.SearchTerms.next(term);

    // if searchBox is empty, then clear SelectedSyst
    if (!term.trim()) {
      this.onSelect(null);  // new MDLEmpl
    }
  }

  onSelect(Empl: MDLEmpl): void {
    if (Empl != this.SelectedEmpl) {
      this.SelectedEmpl = Empl;
      this.IsEmplSelected.emit(true);
    }
  }
}
