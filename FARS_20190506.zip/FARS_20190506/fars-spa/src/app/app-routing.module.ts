import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SystListComponent } from './syst-list/syst-list.component';
import { SystEditorComponent } from './syst-editor/syst-editor.component';
import { SystAuthComponent } from './syst-auth/syst-auth.component';
import { AuthMainComponent } from './auth-main/auth-main.component';
import { EmplAuthComponent } from './empl-auth/empl-auth.component';
import { AuthReportComponent } from './auth-report/auth-report.component';
import { PoolListComponent } from './pool-list/pool-list.component';
import { PoolImportComponent } from './pool-import/pool-import.component';
import { CmprComponent } from './cmpr/cmpr.component';

const routes: Routes = [
  { path: '', redirectTo: '/syst-list', pathMatch: 'full' },
  { path: 'syst-list', component: SystListComponent },
  { path: 'syst-editor/:id', component: SystEditorComponent },
  { path: 'syst-editor', component: SystEditorComponent },
  { path: 'syst-auth/:id', component: SystAuthComponent },
  { path: 'syst-auth', component: SystAuthComponent },
  { path: 'auth-main', component: AuthMainComponent },
  { path: 'empl-auth/:id', component: EmplAuthComponent },
  { path: 'auth-report', component: AuthReportComponent },
  { path: 'pool-list', component: PoolListComponent },
  { path: 'pool-import', component: PoolImportComponent },
  { path: 'cmpr', component: CmprComponent },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
