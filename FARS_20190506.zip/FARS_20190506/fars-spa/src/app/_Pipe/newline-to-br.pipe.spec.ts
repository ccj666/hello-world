import { NewlineToBrPipe } from './newline-to-br.pipe';

describe('NewlineToBrPipe', () => {
  it('create an instance', () => {
    const pipe = new NewlineToBrPipe();
    expect(pipe).toBeTruthy();
  });
});
