import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

import { MDLAuth } from '../_Model/MDLAuth';
import { EmplSearchComponent } from "../empl-search/empl-search.component";
import { SystSearchComponent } from "../syst-search/syst-search.component";
import { AuthEditorComponent } from "../auth-editor/auth-editor.component";
import { AuthService } from '../_Service/auth.service';

@Component({
  selector: 'app-auth-main',
  templateUrl: './auth-main.component.html',
  styleUrls: ['./auth-main.component.css']
})
export class AuthMainComponent implements OnInit {

  AuthForm: FormGroup;

  AuthList: MDLAuth[];

  SelectedAuth: MDLAuth;

  @ViewChild(EmplSearchComponent) Child_EmplSearch: EmplSearchComponent ; 
  @ViewChild(SystSearchComponent) Child_SystSearch: SystSearchComponent ; 
  @ViewChild(AuthEditorComponent) Child_AuthEditor: AuthEditorComponent ; 

  constructor(
    private AuthService: AuthService) { }

  ngOnInit() {
  }

  IsAuthEditor(): boolean {
    return false;
  }

  SelectEmplOrSyst(): void {
    // close auth-editor
    this.Child_AuthEditor.Auth = null;

    //
    let EmplId: string = '';
    let SystId: number = 0;

    if (this.Child_EmplSearch.SelectedEmpl)
      EmplId = this.Child_EmplSearch.SelectedEmpl.Id;

    if (this.Child_SystSearch.SelectedSyst)
      SystId = this.Child_SystSearch.SelectedSyst.Id;

    this.AuthService.getAuthListByEmplSyst(EmplId, SystId)
      .subscribe(AuthList => this.AuthList = AuthList);
  }

  onSelectAuth(Auth: MDLAuth): void {
    //console.log("Auth: ", Auth);
    this.SelectedAuth = Auth;
    this.Child_AuthEditor.BindAuthForm(Auth);
  }

  DeselectAuth(): void {
    if (this.SelectedAuth)
      this.SelectedAuth = null;
  }

  AddAuth(): void {
    //console.log("AddAuth!");

    // clear selection
    this.DeselectAuth();

    // initialize AuthForm
    const dp = new DatePipe(navigator.language);
    let Auth: MDLAuth = new MDLAuth;
    Auth.EmplId = this.Child_EmplSearch.SelectedEmpl.Id;
    Auth.SystId = this.Child_SystSearch.SelectedSyst.Id;
    Auth.SystCode = this.Child_SystSearch.SelectedSyst.Code;
    Auth.EmplName = this.Child_EmplSearch.SelectedEmpl.Name;
    Auth.SystName = this.Child_SystSearch.SelectedSyst.Name;
    this.Child_AuthEditor.BindAuthForm(Auth);
  }

  IsAuthActive(Auth: MDLAuth): boolean {
    const Now = new Date();
    if (Now >= new Date(Auth.ActiveDate) && Now < new Date(Auth.DeactiveDate))
      return true;
    else
      return false;
  }
}
