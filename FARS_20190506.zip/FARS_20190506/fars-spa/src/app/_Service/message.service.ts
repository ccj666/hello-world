import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { MDLMessage } from '../_Model/MDLMessage';

@Injectable({
  providedIn: 'root',
})
export class MessageService {
  MessageList: MDLMessage[] = [];

  add(Message: MDLMessage) {
    this.MessageList.unshift(Message);  // 最新的訊息顯示在最前面

    // 最多只保留 5 筆訊息
    if (this.MessageList.length > 5) {
      this.MessageList.splice(5);
    }
  }

  clear() {
    this.MessageList = [];
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      //console.log('typeof(resp.error.Description):', typeof(resp.error.Description));

      if (typeof(resp.error.Description) == 'undefined')
        this.log(`${operation} failed: ${resp.message}`, true);
      else  // return MDLError
        this.log(`${operation} failed: ${resp.error.Description}`, true);

      // Let the app keep running by returning result.
      return of(result as T);
    };
  }  

  log(message: string, IsError?: boolean) {
    if (IsError)
      this.add({ IsError: true, Text: message});  // `SystService: ${message}`
    else
      this.add({ IsError: false, Text: message});
  }
}