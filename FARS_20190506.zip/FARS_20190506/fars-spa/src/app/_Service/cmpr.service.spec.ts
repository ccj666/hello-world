import { TestBed } from '@angular/core/testing';

import { CmprService } from './cmpr.service';

describe('CmprService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CmprService = TestBed.get(CmprService);
    expect(service).toBeTruthy();
  });
});
