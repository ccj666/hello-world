import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { MDLEmpl } from '../_Model/MDLEmpl';
import { MessageService } from '../_Service/message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class EmplService {

  private EmplUrl = '/fars-api/empl';  // URL to web api

  constructor(private http: HttpClient,
    private MsgService: MessageService) { }
 
  getEmplList(): Observable<MDLEmpl[]> {
    return this.http.get<MDLEmpl[]>(this.EmplUrl)
      .pipe(
        tap(_ => this.MsgService.log('fetched EmplList')),
        catchError(this.MsgService.handleError('getEmplList', []))
      );
  }

  /** GET Empl by id. Will 404 if id not found */
  getEmpl(id: number): Observable<MDLEmpl> {
    const url = `${this.EmplUrl}/${id}`;
    return this.http.get<MDLEmpl>(url).pipe(
      tap(_ => this.MsgService.log(`fetched Empl id=${id}`)),
      catchError(this.MsgService.handleError<MDLEmpl>(`getEmpl id=${id}`))
    );
  }

  /* GET EmplList whose name contains search term */
  searchEmplList(term: string): Observable<MDLEmpl[]> {
    if (!term.trim()) {
      // if not search term, return empty Empl array.
      return of([]);
    }
    return this.http.get<MDLEmpl[]>(`${this.EmplUrl}/?Search=${term}`).pipe(
      tap(_ => this.MsgService.log(`fetched EmplList matching "${term}"`)),
      catchError(this.MsgService.handleError<MDLEmpl[]>('searchEmplList', []))
    );
  }

  /** GET Empl by id. Return `undefined` when id not found */
  /*getEmpl<Data>(id: number): Observable<MDLEmpl> {
    const url = `${this.EmplUrl}/?id=${id}`;
    return this.http.get<MDLEmpl[]>(url)
      .pipe(
      map(Empl => Empl[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.MsgService.log(`${outcome} Empl id=${id}`);
        }),
      catchError(this.MsgService.handleError<MDLEmpl>(`getEmpl id=${id}`))
      );
  }*/

  /** POST: add a new Empl to the server */
  addEmpl(Empl: MDLEmpl): Observable<MDLEmpl> {
    return this.http.post<MDLEmpl>(this.EmplUrl, Empl, httpOptions).pipe(
      tap((Empl: MDLEmpl) => this.MsgService.log(`added Empl w/ id=${Empl.Id}`)),
      catchError(this.MsgService.handleError<MDLEmpl>('addEmpl'))
    );
  }

  /** PUT: update the Empl on the server */
  updateEmpl(Empl: MDLEmpl): Observable<any> {
    const id = Empl.Id;
    const url = `${this.EmplUrl}/${id}`;

    return this.http.put(url, Empl, httpOptions).pipe(
      tap(_ => this.MsgService.log(`updated Empl id=${Empl.Id}`)),
      catchError(this.MsgService.handleError<any>('updateEmpl'))
    );
  }

  /** DELETE: delete the Empl from the server */
  deleteEmpl(Empl: MDLEmpl | number): Observable<MDLEmpl> {
    const id = typeof Empl === 'number' ? Empl : Empl.Id;
    const url = `${this.EmplUrl}/${id}`;

    return this.http.delete<MDLEmpl>(url, httpOptions).pipe(
      tap(_ => this.MsgService.log(`deleted Empl id=${id}`)),
      catchError(this.MsgService.handleError<MDLEmpl>('deleteEmpl'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      if (resp.error)  // return MDLError
        this.MsgService.log(`${operation} failed: ${resp.error.Description}`, true);
      else
        this.MsgService.log(`${operation} failed: ${resp.message}`, true);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/
 
  /** Log a EmplService message with the MessageService */
  /*private log(message: string, IsError?: boolean) {
    if (IsError)
      this.MsgService.add({ IsError: true, Text: `SystService: ${message}`});
    else
      this.MsgService.add({ IsError: false, Text: `SystService: ${message}`});
  }*/
}
