import { TestBed } from '@angular/core/testing';

import { SystService } from './syst.service';

describe('SystService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SystService = TestBed.get(SystService);
    expect(service).toBeTruthy();
  });
});
