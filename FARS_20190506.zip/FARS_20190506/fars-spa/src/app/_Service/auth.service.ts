import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { MDLAuth } from '../_Model/MDLAuth';
import { MessageService } from '../_Service/message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private AuthUrl = '/fars-api/auth';  // URL to web api

  constructor(private http: HttpClient,
    private MsgService: MessageService) { }
 
  getAuthList(): Observable<MDLAuth[]> {
    return this.http.get<MDLAuth[]>(this.AuthUrl)
      .pipe(
        tap(_ => this.MsgService.log('fetched AuthList')),
        catchError(this.MsgService.handleError('getAuthList', []))
      );
  }

  getAuthReport(Frequency: string): Observable<MDLAuth[]> {
    const url = `${this.AuthUrl}/Report/${Frequency}`;
    //console.log("url:", url);
    return this.http.get<MDLAuth[]>(url)
      .pipe(
        tap(_ => this.MsgService.log('fetched AuthReport')),
        catchError(this.MsgService.handleError('getAuthReport', []))
      );
  }

  /** GET Auth by id. Will 404 if id not found */
  getAuth(id: number): Observable<MDLAuth> {
    const url = `${this.AuthUrl}/${id}`;
    return this.http.get<MDLAuth>(url).pipe(
      tap(_ => this.MsgService.log(`fetched Auth id=${id}`)),
      catchError(this.MsgService.handleError<MDLAuth>(`getAuth id=${id}`))
    );
  }

  /** GET Auth by id. Return `undefined` when id not found */
  /*getAuth<Data>(id: number): Observable<MDLAuth> {
    const url = `${this.AuthUrl}/?id=${id}`;
    return this.http.get<MDLAuth[]>(url)
      .pipe(
      map(Auth => Auth[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.MsgService.log(`${outcome} Auth id=${id}`);
        }),
      catchError(this.MsgService.handleError<MDLAuth>(`getAuth id=${id}`))
      );
  }*/

  /* GET AuthList */
  getAuthListByEmplSyst(EmplId: string, SystId: number): Observable<MDLAuth[]> {
    /*console.log("EmplId:", EmplId);
    console.log("SystId:", SystId);
    if (!EmplId.trim()) {
      // if not search EmplId, return empty Auth array.
      return of([]);
    }*/
    return this.http.get<MDLAuth[]>(`${this.AuthUrl}/?EmplId=${EmplId}&SystId=${SystId}`).pipe(
      tap(_ => this.MsgService.log(`fetched AuthList matching EmplId=${EmplId} and SystId=${SystId}`)),
      catchError(this.MsgService.handleError<MDLAuth[]>('getAuthListByEmplSyst', []))
    );
  }

  /* GET AuthList */
  /*getAuthListByEmplSyst(EmplId: string, SystId: number): Observable<MDLAuth[]> {
    return this.http.get<MDLAuth[]>(`${this.AuthUrl}/?EmplId=${EmplId}&SystId=${SystId}`).pipe(
      tap(_ => this.MsgService.log(`fetched AuthList matching EmplId=${EmplId} and SystId=${SystId}`)),
      catchError(_ => { 
        this.MsgService.log(`did not find AuthList matching EmplId=${EmplId} and SystId=${SystId}`);
        return of([]); })
    );
  }*/

  /** POST: add a new Auth to the server */
  addAuth(Auth: MDLAuth): Observable<MDLAuth> {
    //console.log("add Auth:", Auth);
    return this.http.post<MDLAuth>(this.AuthUrl, Auth, httpOptions).pipe(
      tap((Auth: MDLAuth) => this.MsgService.log(`added Auth w/ id=${Auth.Id}`)),
      catchError(this.MsgService.handleError<MDLAuth>('addAuth'))
    );
  }

  /** PUT: update the Auth on the server */
  updateAuth(Auth: MDLAuth): Observable<MDLAuth> {
    //console.log("update Auth:", Auth);
    const id = Auth.Id;
    const url = `${this.AuthUrl}/${id}`;

    return this.http.put(url, Auth, httpOptions).pipe(
      tap((Auth: MDLAuth) => this.MsgService.log(`updated Auth id=${Auth.Id}`)),
      catchError(this.MsgService.handleError<any>('updateAuth'))
    );
  }

  /** DELETE: delete the Auth from the server */
  deleteAuth(Auth: MDLAuth | number): Observable<MDLAuth> {
    const id = typeof Auth === 'number' ? Auth : Auth.Id;
    const url = `${this.AuthUrl}/${id}`;

    return this.http.delete<MDLAuth>(url, httpOptions).pipe(
      tap(_ => this.MsgService.log(`deleted Auth id=${id}`)),
      catchError(this.MsgService.handleError<MDLAuth>('deleteAuth'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      if (resp.error)  // return MDLError
        this.MsgService.log(`${operation} failed: ${resp.error.Description}`, true);
      else
        this.MsgService.log(`${operation} failed: ${resp.message}`, true);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/
 
  /** Log a AuthService message with the MessageService */
  /*private log(message: string, IsError?: boolean) {
    if (IsError)
      this.MsgService.add({ IsError: true, Text: `SystService: ${message}`});
    else
      this.MsgService.add({ IsError: false, Text: `SystService: ${message}`});
  }*/
}
