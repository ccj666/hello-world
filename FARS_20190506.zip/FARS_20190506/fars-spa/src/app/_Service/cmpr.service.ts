import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { MDLCmpr } from '../_Model/MDLCmpr';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CmprService {

  private CmprUrl = '/fars-api/cmpr';  // URL to web api

  constructor(private http: HttpClient,
    private MsgService: MessageService) { }
 
  getCmprList(): Observable<MDLCmpr[]> {
    return this.http.get<MDLCmpr[]>(this.CmprUrl)
      .pipe(
        tap(_ => this.MsgService.log('fetched CmprList')),
        catchError(this.MsgService.handleError('getCmprList', []))
      );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      if (resp.error)  // return MDLError
        this.MsgService.log(`${operation} failed: ${resp.error.Description}`, true);
      else
        this.MsgService.log(`${operation} failed: ${resp.message}`, true);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/
 
  /** Log a CmprService message with the MessageService */
  /*private log(message: string, IsError?: boolean) {
    if (IsError)
      this.MsgService.add({ IsError: true, Text: `SystService: ${message}`});
    else
      this.MsgService.add({ IsError: false, Text: `SystService: ${message}`});
  }*/
}
