import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { MDLSyst } from '../_Model/MDLSyst';
import { MDLError } from '../_Model/MDLError';
import { MessageService } from '../_Service/message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SystService {

  private SystUrl = '/fars-api/syst';  // URL to web api

  constructor(private http: HttpClient,
    private MsgService: MessageService) { }
 
  getSystList(): Observable<MDLSyst[]> {
    return this.http.get<MDLSyst[]>(this.SystUrl)
      .pipe(
        tap(_ => this.MsgService.log('fetched SystList')),
        catchError(this.MsgService.handleError('getSystList', []))
      );
  }

  /** GET Syst by id. Will 404 if id not found */
  getSyst(id: number): Observable<MDLSyst> {
    const url = `${this.SystUrl}/${id}`;
    return this.http.get<MDLSyst>(url).pipe(
      tap(_ => this.MsgService.log(`fetched Syst id=${id}`)),
      catchError(this.MsgService.handleError<MDLSyst>(`getSyst id=${id}`))
    );
  }

  /** GET hero by id. Return `undefined` when id not found */
  /*getSyst<Data>(id: number): Observable<MDLSyst> {
    const url = `${this.SystUrl}/?id=${id}`;
    return this.http.get<MDLSyst[]>(url)
      .pipe(
      map(Syst => Syst[0]), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? `fetched` : `did not find`;
          this.MsgService.log(`${outcome} hero id=${id}`);
        }),
      catchError(this.MsgService.handleError<MDLSyst>(`getSyst id=${id}`))
      );
  }*/

  /* GET SystList whose name contains search term */
  searchSystList(term: string): Observable<MDLSyst[]> {
    if (!term.trim()) {
      // if not search term, return empty Syst array.
      return of([]);
    }
    return this.http.get<MDLSyst[]>(`${this.SystUrl}/?Search=${term}`).pipe(
      tap(_ => this.MsgService.log(`fetched SystList matching "${term}"`)),
      catchError(this.MsgService.handleError<MDLSyst[]>('searchSystList', []))
    );
  }

  getSystHasAuth(Frequency: string): Observable<MDLSyst[]> {
    const url = `${this.SystUrl}/HasAuth/${Frequency}`;
    //console.log("url:", url);
    return this.http.get<MDLSyst[]>(url)
      .pipe(
        tap(_ => this.MsgService.log('fetched SystHasAuth')),
        catchError(this.MsgService.handleError('getSystHasAuth', []))
      );
  }

  /** POST: add a new Syst to the server */
  addSyst(Syst: MDLSyst): Observable<MDLSyst> {
    //console.log("add Syst:", Syst);
    return this.http.post<MDLSyst>(this.SystUrl, Syst, httpOptions).pipe(
      tap((Syst: MDLSyst) => this.MsgService.log(`added Syst w/ id=${Syst.Id}`)),
      catchError(this.MsgService.handleError<MDLSyst>('addSyst'))
    );
  }

  /** PUT: update the Syst on the server */
  updateSyst(Syst: MDLSyst): Observable<MDLSyst> {
    //console.log("updateSyst:", Syst);

    const id = Syst.Id;
    const url = `${this.SystUrl}/${id}`;

    return this.http.put(url, Syst, httpOptions).pipe(
      tap((Syst: MDLSyst) => this.MsgService.log(`updated Syst id=${Syst.Id}`)),
      catchError(this.MsgService.handleError<MDLSyst>('updateSyst'))
    );
  }

  /** PUT: update the Syst on the server */
  /*updateSyst(Syst: MDLSyst): Observable<any> {
    const id = Syst.Id;
    const url = `${this.SystUrl}/${id}`;

    return this.http.put(url, Syst, httpOptions).pipe(
      tap(_ => this.MsgService.log(`updated Syst id=${Syst.Id}`)),
      catchError(this.MsgService.handleError<any>('updateSyst'))
    );
  }*/

  /** DELETE: delete the Syst from the server */
  deleteSyst(Syst: MDLSyst | number): Observable<MDLError> {
    const id = typeof Syst === 'number' ? Syst : Syst.Id;
    const url = `${this.SystUrl}/${id}`;

    return this.http.delete<MDLError>(url, httpOptions).pipe(
      tap(_ => this.MsgService.log(`deleted Syst id=${id}`)),  // if succeed, return null
      catchError(this.MsgService.handleError<MDLError>('deleteSyst', new MDLError))  // if fail, return an empty MDLError
    );
  }

  /** DELETE: delete the Syst from the server */
  /*deleteSyst(Syst: MDLSyst | number): Observable<MDLSyst> {
    const id = typeof Syst === 'number' ? Syst : Syst.Id;
    const url = `${this.SystUrl}/${id}`;

    return this.http.delete<MDLSyst>(url, httpOptions).pipe(
      tap(_ => this.MsgService.log(`deleted Syst id=${id}`)),
      catchError(this.MsgService.handleError<MDLSyst>('deleteSyst'))
    );
  }*/

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      if (resp.error)  // return MDLError
        this.MsgService.log(`${operation} failed: ${resp.error.Description}`, true);
      else
        this.MsgService.log(`${operation} failed: ${resp.message}`, true);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/

  /** Log a SystService message with the MessageService */
  /*private log(message: string, IsError?: boolean) {
    if (IsError)
      this.MsgService.add({ IsError: true, Text: `SystService: ${message}`});
    else
      this.MsgService.add({ IsError: false, Text: `SystService: ${message}`});
  }*/
}
