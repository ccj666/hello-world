import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { MDLPool, MDLPool_Add } from '../_Model/MDLPool';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class PoolService {

  private PoolUrl = '/fars-api/pool';  // URL to web api

  constructor(private http: HttpClient,
    private MsgService: MessageService) { }
 
  getPoolList(): Observable<MDLPool[]> {
    return this.http.get<MDLPool[]>(this.PoolUrl)
      .pipe(
        tap(_ => this.MsgService.log('fetched PoolList')),
        catchError(this.MsgService.handleError('getPoolList', []))
      );
  }
 
  /*goMapping(): void {
    return this.http.put(url, Pool, httpOptions).pipe(
      tap(_ => this.MsgService.log('goMapping')),
      catchError(this.MsgService.handleError<any>('goMapping'))
    );
  }*/

  /** GET Pool by id. Will 404 if id not found */
  getPool(id: number): Observable<MDLPool> {
    const url = `${this.PoolUrl}/${id}`;
    return this.http.get<MDLPool>(url).pipe(
      tap(_ => this.MsgService.log(`fetched Pool id=${id}`)),
      catchError(this.MsgService.handleError<MDLPool>(`getPool id=${id}`))
    );
  }

  /** POST: add PoolList to the server */
  addPoolList(PoolList: MDLPool_Add[]): Observable<MDLPool_Add[]> {
    const url = `${this.PoolUrl}/PostList`;
    //console.log("addPoolList:", url, PoolList);
    return this.http.post<MDLPool_Add[]>(url, PoolList, httpOptions).pipe(
      tap(_ => this.MsgService.log('added PoolList')),
      catchError(this.MsgService.handleError<MDLPool_Add[]>('addPoolList'))
    );
  }

  /** POST: add a new Pool to the server */
  addPool(Pool: MDLPool): Observable<MDLPool> {
    //console.log("addPool:", this.PoolUrl, Pool);
    return this.http.post<MDLPool>(this.PoolUrl, Pool, httpOptions).pipe(
      tap((Pool: MDLPool) => this.MsgService.log(`added Pool w/ id=${Pool.Id}`)),
      catchError(this.MsgService.handleError<MDLPool>('addPool'))
    );
  }

  /** PUT: update the Pool on the server */
  updatePool(Pool: MDLPool): Observable<any> {
    const id = Pool.Id;
    const url = `${this.PoolUrl}/${id}`;

    return this.http.put(url, Pool, httpOptions).pipe(
      tap(_ => this.MsgService.log(`updated Pool id=${Pool.Id}`)),
      catchError(this.MsgService.handleError<any>('updatePool'))
    );
  }

  /** DELETE: delete the Pool from the server */
  deletePool(Pool: MDLPool | number): Observable<MDLPool> {
    const id = typeof Pool === 'number' ? Pool : Pool.Id;
    const url = `${this.PoolUrl}/${id}`;

    return this.http.delete<MDLPool>(url, httpOptions).pipe(
      tap(_ => this.MsgService.log(`deleted Pool id=${id}`)),
      catchError(this.MsgService.handleError<MDLPool>('deletePool'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  /*private handleError<T> (operation = 'operation', result?: T) {
    return (resp: HttpErrorResponse): Observable<T> => {
      if (resp.error)  // return MDLError
        this.MsgService.log(`${operation} failed: ${resp.error.Description}`, true);
      else
        this.MsgService.log(`${operation} failed: ${resp.message}`, true);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }*/
 
  /** Log a PoolService message with the MessageService */
  /*private log(message: string, IsError?: boolean) {
    if (IsError)
      this.MsgService.add({ IsError: true, Text: `SystService: ${message}`});
    else
      this.MsgService.add({ IsError: false, Text: `SystService: ${message}`});
  }*/
}
