import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';

import { AuthService } from '../_Service/auth.service';
import { SystService } from '../_Service/syst.service';
import { MDLSyst } from '../_Model/MDLSyst';
import { MDLAuth } from '../_Model/MDLAuth';

class MDLReport {
  EmplId: string = '';
  EmplName: string = '';
  DeptName: string = '';
  SystRoles: MDLSystRole[];
}

class MDLSystRole {
  SystId: number;
  Roles: string;
}

/*class MDLRole {
  AcctArea: string = '';
  AcctRole: string = '';
}*/

@Component({
  selector: 'app-auth-report',
  templateUrl: './auth-report.component.html',
  styleUrls: ['./auth-report.component.css']
})
export class AuthReportComponent implements OnInit {

  FreqList = [{ Text: '月', Value: 'M' }, { Text: '季', Value: 'S' }, { Text: '半年', Value: 'H' }, { Text: '年', Value: 'Y' }];
  SelectedFreq = this.FreqList[0];
  SystList: MDLSyst[];
  AuthList: MDLAuth[];
  ReportList: MDLReport[];

  constructor(
    private AuthService: AuthService,
    private SystService: SystService
    ) { }

  ngOnInit() {
    this.getAuthReport();
  }

  OnFreqChange(): void {
    this.getAuthReport();
  }

  getAuthReport(): void {
    // clear first
    this.SystList = [];
    this.AuthList = [];
    this.ReportList = [];

    //
    this.SystService.getSystHasAuth(this.SelectedFreq.Value)
      .subscribe(Value => {
        this.SystList = Value;
        //console.log('this.SystList:', this.SystList);
        
        // getAuthReport_Sub()必須包含在getSystHasAuth().subscribe()裡面, 如此才可以確保先取得this.SystList, 因為後面的程式會用到this.SystList
        this.getAuthReport_Sub();
      });

  }

  getAuthReport_Sub(): void {
      this.AuthService.getAuthReport(this.SelectedFreq.Value)
      .subscribe(Value => {
        this.AuthList = Value;
        //console.log('this.AuthList.length:', this.AuthList.length);

        let L_EmplId: string = '';
        let L_SystId: number = 0;
        let EmplRow: MDLReport;
        let Roles: string = '';  

        Value.forEach(Auth => {
          //console.log('Auth.Id:', Auth.Id, ', L_EmplId:', L_EmplId, ', L_SystId:', L_SystId);

          //
          if (Auth.EmplId != L_EmplId) {  // EmplId is changed
            if (L_SystId > 0) {
              // save previous Roles
              EmplRow.SystRoles.find(Item => Item.SystId === L_SystId).Roles = Roles;
              //console.log('save previous Roles to EmplRow:', EmplRow);

              // push previous EmplRow
              //console.log('push previous EmplRow:', EmplRow);
              this.ReportList.push(EmplRow);
            }
        
            // initialize Roles
            Roles = '(' + Auth.AcctArea + ')' + Auth.AcctRole;
            L_SystId = Auth.SystId;

            // create a new EmplRow
            EmplRow = {
              EmplId: Auth.EmplId,
              EmplName: Auth.EmplName,
              DeptName: Auth.DeptName,
              SystRoles: []
            };
            for (let i = 0; i < this.SystList.length; i++) {
              EmplRow.SystRoles.push({ SystId: this.SystList[i].Id, Roles: "" });
            }
            //console.log('new EmplRow:', EmplRow);
    
            //
            L_EmplId = Auth.EmplId;
          } 
          else if (Auth.SystId != L_SystId) {  // SystId is changed
            if (L_SystId > 0) {
              // save previous Roles
              EmplRow.SystRoles.find(Item => Item.SystId === L_SystId).Roles = Roles;
              //console.log('save previous Roles to EmplRow:', EmplRow);
            }
    
            // initialize Roles
            Roles = '(' + Auth.AcctArea + ')' + Auth.AcctRole;
            L_SystId = Auth.SystId;
          } 
          else {  // SystId is not changed
            Roles = Roles + '\n(' + Auth.AcctArea + ')' + Auth.AcctRole;
          }
        });

        //
        if (L_SystId > 0) {
          // save last Roles
          EmplRow.SystRoles.find(Item => Item.SystId === L_SystId).Roles = Roles;
          //console.log('save last Roles to EmplRow:', EmplRow);

          // push last EmplRow
          //console.log('push last EmplRow:', EmplRow);
          this.ReportList.push(EmplRow);
        }
      });
  }

  ExportToExcel(): void {
    let SheetData: string[][] = [];
    let Row: string[];
    const dp = new DatePipe(navigator.language);

    // first row
    Row = ["編號", "部門", "員工編號", "姓名"];
    this.SystList.forEach(Syst => {
      Row.push(Syst.Name);
    });
    SheetData.push(Row);

    Row = ["檢核頻率", "", "", ""];
    this.SystList.forEach(Syst => {
      Row.push(this.SelectedFreq.Text);
    });
    SheetData.push(Row);

    Row = ["附件", "", "", ""];
    this.SystList.forEach(Syst => {
      Row.push(Syst.AuthAnnex);
    });
    SheetData.push(Row);

    Row = ["資料提供日", "", "", ""];
    this.SystList.forEach(Syst => {
      Row.push(dp.transform(Syst.AuthProvide, 'yyyy/M/d'));
    });
    SheetData.push(Row);

    let i = 0;
    this.ReportList.forEach(Report => {
      i = i + 1;

      Row = [i.toString(), Report.DeptName, Report.EmplId, Report.EmplName];
      Report.SystRoles.forEach(SystRole => {
        Row.push(SystRole.Roles);
      });

      SheetData.push(Row);
    });

    // generate worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(SheetData);

    /*const wscols = [
      {width:50},
      {width:50},
      {width:50},
      {width:50}
    ];
    
    ws['!cols'] = wscols;*/

    ws['!merges'] = [ { s: { c: 0, r: 1 }, e: { c: 3, r: 1 } },  // range A2:D2
                      { s: { c: 0, r: 2 }, e: { c: 3, r: 2 } },  // range A3:D3
                      { s: { c: 0, r: 3 }, e: { c: 3, r: 3 } } ] ;  // range A4:D4

    // generate workbook and add the worksheet
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    // save to file
    XLSX.writeFile(wb, 'FARS_AuthReport.xlsx');
  }
}
