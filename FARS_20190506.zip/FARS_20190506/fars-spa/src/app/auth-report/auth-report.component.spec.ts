import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthReportComponent } from './auth-report.component';

describe('AuthReportComponent', () => {
  let component: AuthReportComponent;
  let fixture: ComponentFixture<AuthReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
