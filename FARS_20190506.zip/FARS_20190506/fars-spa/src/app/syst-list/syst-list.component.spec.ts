import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystListComponent } from './syst-list.component';

describe('SystListComponent', () => {
  let component: SystListComponent;
  let fixture: ComponentFixture<SystListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
