import { Component, OnInit } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { MDLSyst } from '../_Model/MDLSyst';
import { SystService } from '../_Service/syst.service';


@Component({
  selector: 'app-syst-list',
  templateUrl: './syst-list.component.html',
  styleUrls: ['./syst-list.component.css']
})
export class SystListComponent implements OnInit {

  SystList: MDLSyst[];
  private SearchTerms = new Subject<string>();

  constructor(private SystService: SystService) { }

  ngOnInit() {
    this.SearchTerms.pipe(
      // wait 500ms after each keystroke before considering the term
      debounceTime(500),

      // ignore new term if same as previous term
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap((term: string) => this.SystService.searchSystList(term)),
    ).subscribe(Value => this.SystList = Value);

    // list all Syst
    this.Search('%');
  }

  // Push a search term into the observable stream.
  Search(term: string): void {
    this.SearchTerms.next(term);

    //console.log('SearchTerms:', this.SearchTerms);
  }

}
