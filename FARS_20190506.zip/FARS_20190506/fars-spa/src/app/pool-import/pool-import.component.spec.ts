import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoolImportComponent } from './pool-import.component';

describe('PoolImportComponent', () => {
  let component: PoolImportComponent;
  let fixture: ComponentFixture<PoolImportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoolImportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoolImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
