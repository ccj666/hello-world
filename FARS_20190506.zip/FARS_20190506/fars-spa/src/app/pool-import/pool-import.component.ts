import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';

import { MDLPool_Add } from '../_Model/MDLPool';
import { PoolService } from '../_Service/pool.service';

@Component({
  selector: 'app-pool-import',
  templateUrl: './pool-import.component.html',
  styleUrls: ['./pool-import.component.css']
})
export class PoolImportComponent implements OnInit {

  PoolList: MDLPool_Add[] = [];
  ListSheetName: string[];
  //Debug: string = '';

  constructor(
    private PoolService: PoolService
  ) { }

  ngOnInit() {
  }
  
  onFileChange(evt: any) {
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});
      this.ListSheetName = wb.SheetNames;

      let ws: XLSX.WorkSheet;
      let SheetData: string[][];
      let Pool: MDLPool_Add;
      for (let SheetName of this.ListSheetName) {
        ws = wb.Sheets[SheetName];
        SheetData = <any[][]>(XLSX.utils.sheet_to_json(ws, {header: 1}));

        for (let i = 0; i < SheetData.length; i++) {
          let array1 = SheetData[i];
          if (i > 0) {  // ignore header row
            /*let Roles: string[] = [];
            for (let j = 2; j < array1.length; j++) {
              Roles.push(array1[j]);
            }
            //this.Debug = this.Debug + SheetName + '-' + i + '-' + Roles.length + ',';
            Pool = {SystCode: SheetName, AcctArea: array1[0], AcctId: array1[1], AcctRole: JSON.stringify(Roles)};*/
            Pool = {
              SystCode: SheetName, 
              AcctArea: array1[0], 
              AcctId: array1[1], 
              AcctRole1: (array1.length >= 3 ? array1[2] : ''), 
              AcctRole2: (array1.length >= 4 ? array1[3] : ''), 
              AcctRole3: (array1.length >= 5 ? array1[4] : '')};
            this.PoolList.push(Pool);
          }
        }
      }
    };
    reader.readAsBinaryString(target.files[0]);
  }

  onSubmit(): void {
    //console.log("Strange Bug:", this.PoolList[0]);
    //this.PoolService.addPool(this.PoolList[1]).subscribe();
    this.PoolService.addPoolList(this.PoolList).subscribe();

    //this.router.navigate(['/pool-list']);  /* pool-list 不會立即更新 */
  }

}
