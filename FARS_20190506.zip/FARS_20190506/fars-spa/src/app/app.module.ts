import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ErrorStateMatcher } from '@angular/material/core';

import { registerLocaleData } from '@angular/common';
import localeZh from '@angular/common/locales/zh';
/*import localeZhExtra from '@angular/common/locales/extra/zh';*/

registerLocaleData(localeZh, 'zh');  // , localeZhExtra

import { SystListComponent } from './syst-list/syst-list.component';
import { SystEditorComponent } from './syst-editor/syst-editor.component';
import { MessagesComponent } from './messages/messages.component';
import { SystAuthComponent } from './syst-auth/syst-auth.component';
import { AuthMainComponent } from './auth-main/auth-main.component';
import { AuthEditorComponent } from './auth-editor/auth-editor.component';
import { SystSearchComponent } from './syst-search/syst-search.component';
import { EmplSearchComponent } from './empl-search/empl-search.component';
import { EmplSearch2Component } from './empl-search-2/empl-search-2.component';
import { EmplAuthComponent } from './empl-auth/empl-auth.component';
import { PoolImportComponent } from './pool-import/pool-import.component';
import { PoolListComponent } from './pool-list/pool-list.component';
import { AuthReportComponent } from './auth-report/auth-report.component';
import { CmprComponent } from './cmpr/cmpr.component';
import { NewlineToBrPipe } from './_Pipe/newline-to-br.pipe';
import { NotDateValidatorDirective } from './_Directive/not-date-validator.directive';
import { TwoDatesLargeToSmallValidatorDirective } from './_Directive/two-dates-large-to-small-validator.directive';
import { TestValidatorDirective } from './_Directive/test-validator.directive';

@NgModule({
  declarations: [
    AppComponent,
    SystListComponent,
    SystEditorComponent,
    MessagesComponent,
    SystAuthComponent,
    AuthMainComponent,
    AuthEditorComponent,
    SystSearchComponent,
    EmplSearchComponent,
    EmplSearch2Component,
    EmplAuthComponent,
    PoolImportComponent,
    PoolListComponent,
    AuthReportComponent,
    CmprComponent,
    NewlineToBrPipe,
    NotDateValidatorDirective,
    TwoDatesLargeToSmallValidatorDirective,
    TestValidatorDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserModule
  ],
  providers: [ { provide: LOCALE_ID, useValue: 'zh' } ],
  bootstrap: [AppComponent]
})
export class AppModule { }
