import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystAuthComponent } from './syst-auth.component';

describe('SystAuthComponent', () => {
  let component: SystAuthComponent;
  let fixture: ComponentFixture<SystAuthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystAuthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
