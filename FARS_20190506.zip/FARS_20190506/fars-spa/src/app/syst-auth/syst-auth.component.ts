import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';

import { MDLSyst } from '../_Model/MDLSyst';
import { SystService } from '../_Service/syst.service';

@Component({
  selector: 'app-syst-auth',
  templateUrl: './syst-auth.component.html',
  styleUrls: ['./syst-auth.component.css']
})
export class SystAuthComponent implements OnInit {
  @Input() Syst: MDLSyst;

  AuthForm: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private SystService: SystService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.getSyst();
  }

  getSyst(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    //console.log("id:", id);
    if (id == 0) {  // add new
      this.Syst = new MDLSyst();
      //this.AuthForm = this.fb.group(this.Syst);
    }
    else {  // edit
      this.SystService.getSyst(id)
        .subscribe(Syst => {
          if (Syst) {
            this.Syst = Syst;
            //this.AuthForm = this.fb.group(Syst);
          }
          else {
            this.router.navigate(['/syst-list']);
          }
        });
    }
  }

  onSubmit() {
    const id = +this.route.snapshot.paramMap.get('id');

    // These values are still referenced by our form. If we just copy that reference and modify the data elsewhere, the form will be impacted, as well. This can cause weird side-effects.
    // So, we need to create a copy of the data
    const AuthFormValue: MDLSyst = Object.assign({}, this.AuthForm.value);

    // update database
    if (id == 0)
      this.SystService.addSyst(AuthFormValue)
        .subscribe();  //() => this.goBack()
    else
      this.SystService.updateSyst(AuthFormValue)
        .subscribe();  //() => this.goBack()
  }

  goBack(): void {
    this.router.navigate(['/syst-list']);
  }

}
