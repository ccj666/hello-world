import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystEditorComponent } from './syst-editor.component';

describe('SystEditorComponent', () => {
  let component: SystEditorComponent;
  let fixture: ComponentFixture<SystEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
