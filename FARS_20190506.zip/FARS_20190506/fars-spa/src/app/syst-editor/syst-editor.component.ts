import { Component, OnInit, Input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';

import { MDLSyst } from '../_Model/MDLSyst';
import { SystService } from '../_Service/syst.service';
import { NotDateValidator } from '../_Directive/not-date-validator.directive';

@Component({
  selector: 'app-syst-editor',
  templateUrl: './syst-editor.component.html',
  styleUrls: ['./syst-editor.component.css']
})
export class SystEditorComponent implements OnInit {
  @Input() Syst: MDLSyst;

  SystForm: FormGroup;

  TypeList = [{ Text: '內部系統', Value: 'INT' }, { Text: '外部系統', Value: 'EXT' }];
  FreqList = [{ Text: '月', Value: 'M', Checked: false }, 
    { Text: '季', Value: 'S', Checked: false }, 
    { Text: '半年', Value: 'H', Checked: false }, 
    { Text: '年', Value: 'Y', Checked: false }];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private SystService: SystService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.getSyst();
  }

  getSyst(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    //console.log("id:", id);
    //const dp = new DatePipe(navigator.language);

    if (id == 0) {  // add new
      this.BindSystForm(new MDLSyst());
      /*this.Syst = new MDLSyst();
      this.SystForm = this.fb.group({
        Code: '',
        Name: '',
        Type: 'EXT',
        Frequency: this.fb.array([]),
        ContactName: '',
        ContactEmail: '',
        ContactTel: '',
        DisplayOrder: 0,
        AuthAnnex: '',
        AuthProvide: dp.transform(this.Syst.AuthProvide, 'yyyy/M/d')
      });*/
    }
    else {  // edit
      this.SystService.getSyst(id)
        .subscribe(Syst => {
          if (Syst) {
            //console.log("Syst:", Syst);
            this.BindSystForm(Syst);
            /*this.Syst = Syst;
            this.SystForm = this.fb.group({
              Code: Syst.Code,
              Name: Syst.Name,
              Type: Syst.Type,
              Frequency: this.fb.array(Syst.Frequency),
              ContactName: Syst.ContactName,
              ContactEmail: Syst.ContactEmail,
              ContactTel: Syst.ContactTel,
              DisplayOrder: Syst.DisplayOrder,
              AuthAnnex: Syst.AuthAnnex,
              AuthProvide: dp.transform(Syst.AuthProvide, 'yyyy/M/d')
            });

            // initialize FreqList checkbox
            for (let Freq of this.FreqList) {
              Freq.Checked = Syst.Frequency.includes(Freq.Value);
            }*/
          }
          else {
            this.router.navigate(['/syst-list']);
          }
        });
    }
  }

  BindSystForm(Syst: MDLSyst): void {
    if (Syst) {
      const dp = new DatePipe(navigator.language);
      
      this.SystForm = this.fb.group({
        Code: Syst.Code,
        Name: Syst.Name,
        Type: Syst.Type,
        Frequency: this.fb.array(Syst.Frequency),
        ContactName: Syst.ContactName,
        ContactEmail: Syst.ContactEmail,
        ContactTel: Syst.ContactTel,
        DisplayOrder: Syst.DisplayOrder,
        AuthAnnex: Syst.AuthAnnex,
        AuthProvide: new FormControl(dp.transform(Syst.AuthProvide, 'yyyy/M/d'), NotDateValidator)
      });

      // initialize FreqList checkbox
      for (let Freq of this.FreqList) {
        Freq.Checked = Syst.Frequency.includes(Freq.Value);
      }
    }

    //
    this.Syst = Syst;
  }

  onChange(Freq: string, isChecked: boolean) {
    const FreqArray = <FormArray>this.SystForm.controls.Frequency;

    if (isChecked) {
      FreqArray.push(new FormControl(Freq));
    } 
    else {
      let index = FreqArray.controls.findIndex(x => x.value == Freq)
      FreqArray.removeAt(index);
    }
  }

  onSubmit() {
    const id = +this.route.snapshot.paramMap.get('id');

    // These values are still referenced by our form. If we just copy that reference and modify the data elsewhere, the form will be impacted, as well. This can cause weird side-effects.
    // So, we need to create a copy of the data
    const SystFormValue: MDLSyst = Object.assign({}, this.SystForm.value);

    // 因為Object.assign不會Clone下列property, 所以需要另外提供給WebApi.
    SystFormValue.Status = '1';
    SystFormValue.UpdateUser = '';
    //console.log("SystFormValue:", SystFormValue);

    // 
    if (id == 0) {  // add new
      this.SystService.addSyst(SystFormValue)
        .subscribe(Syst => {
          if (Syst)
            this.goBack()
          });  // (Syst => this.Syst = Syst)
    }
    else {  // edit
      SystFormValue.Id = id;
      this.SystService.updateSyst(SystFormValue)
      .subscribe(Syst => {
        if (Syst)
          this.goBack()
        });
    }
  }

  Delete(): void {
    if(confirm("您確定要刪除這個系統?")) {
      this.SystService.deleteSyst(this.Syst.Id)
        .subscribe(Error => {
          //console.log(Error);
          if (!Error)  // delete successfully
            this.goBack()
          }
        );
    }
  }

  goBack(): void {
    this.router.navigate(['/syst-list']);
  }

}
