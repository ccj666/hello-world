﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Oracle.ManagedDataAccess.Client;

using FarsApi.Model;

namespace FarsApi.BLL
{
    public class BLLEmpl
    {
        //
        public ICollection<MDLEmpl> Search(string p_Search)
        {
            // Set up return value
            ICollection<MDLEmpl> EmplList = new List<MDLEmpl>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_EMPL_SEARCH_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_SEARCH", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = p_Search.Trim();
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLEmpl Empl = new MDLEmpl
                            {
                                Id = dr.GetString(0),
                                Status = dr.GetString(1),
                                Name = dr.GetString(2),
                                Email = dr.GetString(3),
                                ADId = dr.GetString(4),
                                Grade = dr.GetInt16(5),
                                DeptId = dr.GetString(6),
                                DeptName = dr.GetString(7),
                                JobTitleName = dr.GetString(8),
                                ArriveDate = dr.GetDateTime(9),
                                LeaveDate = dr.GetDateTime(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12)
                            };
                            EmplList.Add(Empl);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return EmplList;
        }
    }
}