﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Oracle.ManagedDataAccess.Client;

using FarsApi.Model;

namespace FarsApi.BLL
{
    public class BLLPool
    {
        //
        public ICollection<MDLPool> GetAll()
        {
            // Set up return value
            ICollection<MDLPool> PoolList = new List<MDLPool>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_POOL_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter parm = new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor);

                    // Bind Parameter
                    parm.Direction = ParameterDirection.Output;

                    // Add Parameter
                    cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLPool Pool = new MDLPool
                            {
                                Id = dr.GetInt64(0),
                                SystCode = dr.GetString(1),
                                AcctArea = dr.GetString(2),
                                AcctId = dr.GetString(3),
                                AcctRole = dr.IsDBNull(4) ? "" : dr.GetString(4),
                                AcctEmail = dr.IsDBNull(5) ? "" : dr.GetString(5),
                                SystId = dr.GetInt32(6),
                                IsAcctArea = dr.GetString(7),
                                EmplId = dr.IsDBNull(8) ? "" : dr.GetString(8),
                                MappingBy = dr.IsDBNull(9) ? "" : dr.GetString(9),
                                IsAcctRole = dr.GetString(10),
                                Remark = dr.IsDBNull(11) ? "" : dr.GetString(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                            PoolList.Add(Pool);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return PoolList;
        }

        //
        public void Add(MDLPool_Add Pool)
        {
            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_POOL_I", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_SYST_CODE", OracleDbType.NVarchar2, 20),
                        new OracleParameter("P_ACCT_AREA", OracleDbType.Varchar2, 10),
                        new OracleParameter("P_ACCT_ID", OracleDbType.Varchar2, 255),
                        new OracleParameter("P_ACCT_ROLE1", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_ACCT_ROLE2", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_ACCT_ROLE3", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_UPDATE_USER", OracleDbType.Varchar2, 20)
                    };

                    // Bind Parameter
                    parms[0].Value = Pool.SystCode.Trim();
                    parms[1].Value = Pool.AcctArea.Trim();
                    parms[2].Value = Pool.AcctId.Trim();
                    parms[3].Value = Pool.AcctRole1.Trim();
                    parms[4].Value = Pool.AcctRole2.Trim();
                    parms[5].Value = Pool.AcctRole3.Trim();
                    parms[6].Value = "";  // Pool.UpdateUser;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    cmd.ExecuteNonQuery();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }
        }

        //
        public void DeleteAll()
        {
            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_POOL_ALL_D", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    //
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}