﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Oracle.ManagedDataAccess.Client;

using FarsApi.Model;

namespace FarsApi.BLL
{
    public class BLLSyst
    {
        //
        public ICollection<MDLSyst> GetAll()
        {
            // Set up return value
            ICollection<MDLSyst> SystList = new List<MDLSyst>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter parm = new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor);

                    // Bind Parameter
                    parm.Direction = ParameterDirection.Output;

                    // Add Parameter
                    cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLSyst Syst = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                            SystList.Add(Syst);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return SystList;
        }

        //
        public ICollection<MDLSyst> Search(string p_Search)
        {
            // Set up return value
            ICollection<MDLSyst> SystList = new List<MDLSyst>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_SEARCH_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_SEARCH", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = p_Search.Trim();
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLSyst Syst = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                            SystList.Add(Syst);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return SystList;
        }

        //
        public ICollection<MDLSyst> GetHasAuth(string Frequency)
        {
            // Set up return value
            ICollection<MDLSyst> SystList = new List<MDLSyst>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_HAS_AUTH_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_FREQUENCY", OracleDbType.Char, 1),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Frequency.Trim();
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLSyst Syst = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                            SystList.Add(Syst);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return SystList;
        }

        //
        public MDLSyst Get(int Id)
        {
            // Set up return value
            MDLSyst Syst = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_S", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Id;
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Syst = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Syst;
        }

        //
        public MDLSyst Add(MDLSyst Syst, ref string Result)
        {
            // Set up return value
            MDLSyst Syst2 = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_I", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_STATUS", OracleDbType.Char, 1),
                        new OracleParameter("P_TYPE", OracleDbType.Varchar2, 10),
                        new OracleParameter("P_CODE", OracleDbType.NVarchar2, 20),
                        new OracleParameter("P_NAME", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_FREQUENCY", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_CONTACT_NAME", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_CONTACT_EMAIL", OracleDbType.Varchar2, 255),
                        new OracleParameter("P_CONTACT_TEL", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_DISPLAY_ORDER", OracleDbType.Int16),
                        new OracleParameter("P_AUTH_ANNEX", OracleDbType.NVarchar2, 20),
                        new OracleParameter("P_AUTH_PROVIDE", OracleDbType.Date),
                        new OracleParameter("P_UPDATE_USER", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Syst.Status.Trim();
                    parms[1].Value = Syst.Type.Trim();
                    parms[2].Value = Syst.Code.Trim();
                    parms[3].Value = Syst.Name.Trim();
                    parms[4].Value = string.Join(",", Syst.Frequency);  // ["M", "S"] -> "M,S"
                    parms[5].Value = Syst.ContactName.Trim();
                    parms[6].Value = Syst.ContactEmail.Trim();
                    parms[7].Value = Syst.ContactTel.Trim();
                    parms[8].Value = Syst.DisplayOrder;
                    parms[9].Value = Syst.AuthAnnex;
                    parms[10].Value = Syst.AuthProvide;
                    parms[11].Value = Syst.UpdateUser.Trim();
                    parms[12].Direction = ParameterDirection.Output;
                    parms[13].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Syst2 = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                        }
                    }

                    // Get Result
                    Result = parms[12].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Syst2;
        }

        //
        public MDLSyst Update(MDLSyst Syst, ref string Result)
        {
            // Set up return value
            MDLSyst Syst2 = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_U", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_STATUS", OracleDbType.Char, 1),
                        new OracleParameter("P_TYPE", OracleDbType.Varchar2, 10),
                        new OracleParameter("P_CODE", OracleDbType.NVarchar2, 20),
                        new OracleParameter("P_NAME", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_FREQUENCY", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_CONTACT_NAME", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_CONTACT_EMAIL", OracleDbType.Varchar2, 255),
                        new OracleParameter("P_CONTACT_TEL", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_DISPLAY_ORDER", OracleDbType.Int16),
                        new OracleParameter("P_AUTH_ANNEX", OracleDbType.NVarchar2, 20),
                        new OracleParameter("P_AUTH_PROVIDE", OracleDbType.Date),
                        new OracleParameter("P_UPDATE_USER", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Syst.Id;
                    parms[1].Value = Syst.Status.Trim();
                    parms[2].Value = Syst.Type.Trim();
                    parms[3].Value = Syst.Code.Trim();
                    parms[4].Value = Syst.Name.Trim();
                    parms[5].Value = string.Join(",", Syst.Frequency);  // ["M", "S"] -> "M,S"
                    parms[6].Value = Syst.ContactName.Trim();
                    parms[7].Value = Syst.ContactEmail.Trim();
                    parms[8].Value = Syst.ContactTel.Trim();
                    parms[9].Value = Syst.DisplayOrder;
                    parms[10].Value = Syst.AuthAnnex;
                    parms[11].Value = Syst.AuthProvide;
                    parms[12].Value = Syst.UpdateUser.Trim();
                    parms[13].Direction = ParameterDirection.Output;
                    parms[14].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Syst2 = new MDLSyst
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                Type = dr.GetString(2),
                                Code = dr.GetString(3),
                                Name = dr.GetString(4),
                                Frequency = (dr.IsDBNull(5) ? new string[] { } : dr.GetString(5).Split(',')), //dr.GetString(5).Split(','),
                                ContactName = dr.GetString(6),
                                ContactEmail = dr.GetString(7),
                                ContactTel = dr.GetString(8),
                                DisplayOrder = dr.GetInt16(9),
                                AuthAnnex = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                AuthProvide = dr.GetDateTime(11),  // dr.IsDBNull(11) ? (DateTime?)null : dr.GetDateTime(11),
                                UpdateTime = dr.GetDateTime(12),
                                UpdateUser = dr.IsDBNull(13) ? "" : dr.GetString(13)
                            };
                        }
                    }

                    // Get Result
                    Result = parms[13].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Syst2;
        }

        //
        public void Delete(int Id, ref string Result)
        {
            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_SYST_D", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20)
                    };

                    // Bind Parameter
                    parms[0].Value = Id;
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    cmd.ExecuteNonQuery();

                    // Get Result
                    Result = parms[1].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }
        }
    }
}