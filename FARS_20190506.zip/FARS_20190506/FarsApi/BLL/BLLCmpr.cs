﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Oracle.ManagedDataAccess.Client;

using FarsApi.Model;

namespace FarsApi.BLL
{
    public class BLLCmpr
    {
        //
        public ICollection<MDLCmpr> GetAll()
        {
            // Set up return value
            ICollection<MDLCmpr> CmprList = new List<MDLCmpr>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_CMPR_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter parm = new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor);

                    // Bind Parameter
                    parm.Direction = ParameterDirection.Output;

                    // Add Parameter
                    cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLCmpr Cmpr = new MDLCmpr
                            {
                                Pool_Id = dr.IsDBNull(0) ? 0 : dr.GetInt64(0),
                                Pool_SystCode = dr.IsDBNull(1) ? "" : dr.GetString(1),
                                Pool_AcctArea = dr.IsDBNull(2) ? "" : dr.GetString(2),
                                Pool_AcctId = dr.IsDBNull(3) ? "" : dr.GetString(3),
                                Pool_AcctRole = dr.IsDBNull(4) ? "" : dr.GetString(4),
                                Pool_AcctEmail = dr.IsDBNull(5) ? "" : dr.GetString(5),
                                Pool_SystId = dr.IsDBNull(6) ? 0 : dr.GetInt32(6),
                                Pool_IsAcctArea = dr.IsDBNull(7) ? "" : dr.GetString(7),
                                Pool_EmplId = dr.IsDBNull(8) ? "" : dr.GetString(8),
                                Pool_MappingBy = dr.IsDBNull(9) ? "" : dr.GetString(9),
                                Pool_IsAcctRole = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                Auth_Id = dr.IsDBNull(11) ? 0 : dr.GetInt32(11),
                                Auth_EmplId = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                Auth_SystId = dr.IsDBNull(13) ? 0 : dr.GetInt32(13),
                                Auth_SystCode = dr.IsDBNull(14) ? "" : dr.GetString(14),
                                Auth_AcctArea = dr.IsDBNull(15) ? "" : dr.GetString(15),
                                Auth_AcctId = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                Auth_AcctRole = dr.IsDBNull(17) ? "" : dr.GetString(17)
                            };
                            CmprList.Add(Cmpr);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return CmprList;
        }
    }
}