﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Oracle.ManagedDataAccess.Client;

using FarsApi.Model;

namespace FarsApi.BLL
{
    public class BLLAuth
    {
        //
        public MDLAuth Get(int Id)
        {
            // Set up return value
            MDLAuth Auth = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_S", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Id;
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Auth = new MDLAuth
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                EmplId = dr.GetString(2),
                                SystId = dr.GetInt32(3),
                                SystCode = dr.GetString(4),
                                AcctArea = dr.GetString(5),
                                AcctId = dr.GetString(6),
                                AcctRole = dr.GetString(7),
                                ActiveDate = dr.GetDateTime(8),
                                DeactiveDate = dr.GetDateTime(9),
                                Remark = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                EmplName = dr.GetString(13),
                                DeptName = dr.GetString(14),
                                SystName = dr.GetString(15),
                                AuthAnnex = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                AuthProvide = dr.GetDateTime(17)  //dr.IsDBNull(17) ? (DateTime?)null : dr.GetDateTime(17)
                            };
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Auth;
        }

        //
        public ICollection<MDLAuth> GetByEmplSyst(string EmplId, int SystId)
        {
            // Set up return value
            ICollection<MDLAuth> AuthList = new List<MDLAuth>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_BY_EMPL_SYST_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_EMPL_ID", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_SYST_ID", OracleDbType.Int32),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = EmplId.Trim();
                    parms[1].Value = SystId;
                    parms[2].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLAuth Auth = new MDLAuth
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                EmplId = dr.GetString(2),
                                SystId = dr.GetInt32(3),
                                SystCode = dr.GetString(4),
                                AcctArea = dr.GetString(5),
                                AcctId = dr.GetString(6),
                                AcctRole = dr.GetString(7),
                                ActiveDate = dr.GetDateTime(8),
                                DeactiveDate = dr.GetDateTime(9),
                                Remark = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                EmplName = dr.GetString(13),
                                DeptName = dr.GetString(14),
                                SystName = dr.GetString(15),
                                AuthAnnex = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                AuthProvide = dr.GetDateTime(17)  // dr.IsDBNull(17) ? (DateTime?)null : dr.GetDateTime(17)
                            };
                            AuthList.Add(Auth);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return AuthList;
        }

        //
        public ICollection<MDLAuth> GetReport(string Frequency)
        {
            // Set up return value
            ICollection<MDLAuth> AuthList = new List<MDLAuth>();

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_REPORT_L", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_FREQUENCY", OracleDbType.Char, 1),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Frequency.Trim();
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            MDLAuth Auth = new MDLAuth
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                EmplId = dr.GetString(2),
                                SystId = dr.GetInt32(3),
                                SystCode = dr.GetString(4),
                                AcctArea = dr.GetString(5),
                                AcctId = dr.GetString(6),
                                AcctRole = dr.GetString(7),
                                ActiveDate = dr.GetDateTime(8),
                                DeactiveDate = dr.GetDateTime(9),
                                Remark = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                EmplName = dr.GetString(13),
                                DeptName = dr.GetString(14),
                                SystName = dr.GetString(15),
                                AuthAnnex = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                AuthProvide = dr.GetDateTime(17)  // dr.IsDBNull(17) ? (DateTime?)null : dr.GetDateTime(17)
                            };
                            AuthList.Add(Auth);
                        }
                    }

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return AuthList;
        }

        //
        public MDLAuth Add(MDLAuth Auth, ref string Result)
        {
            // Set up return value
            MDLAuth Auth2 = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_I", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_STATUS", OracleDbType.Char, 1),
                        new OracleParameter("P_EMPL_ID", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_SYST_ID", OracleDbType.Int32),
                        new OracleParameter("P_ACCT_AREA", OracleDbType.Varchar2, 10),
                        new OracleParameter("P_ACCT_ID", OracleDbType.Varchar2, 255),
                        new OracleParameter("P_ACCT_ROLE", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_ACTIVE_DATE", OracleDbType.Date),
                        new OracleParameter("P_DEACTIVE_DATE", OracleDbType.Date),
                        new OracleParameter("P_REMARK", OracleDbType.NVarchar2, 200),
                        new OracleParameter("P_UPDATE_USER", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Auth.Status.Trim();
                    parms[1].Value = Auth.EmplId.Trim();
                    parms[2].Value = Auth.SystId;
                    parms[3].Value = Auth.AcctArea.Trim();
                    parms[4].Value = Auth.AcctId.Trim();
                    parms[5].Value = Auth.AcctRole.Trim();
                    parms[6].Value = Auth.ActiveDate;
                    parms[7].Value = Auth.DeactiveDate;
                    parms[8].Value = Auth.Remark.Trim();
                    parms[9].Value = Auth.UpdateUser.Trim();
                    parms[10].Direction = ParameterDirection.Output;
                    parms[11].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Auth2 = new MDLAuth
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                EmplId = dr.GetString(2),
                                SystId = dr.GetInt32(3),
                                SystCode = dr.GetString(4),
                                AcctArea = dr.GetString(5),
                                AcctId = dr.GetString(6),
                                AcctRole = dr.GetString(7),
                                ActiveDate = dr.GetDateTime(8),
                                DeactiveDate = dr.GetDateTime(9),
                                Remark = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                EmplName = dr.GetString(13),
                                DeptName = dr.GetString(14),
                                SystName = dr.GetString(15),
                                AuthAnnex = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                AuthProvide = dr.GetDateTime(17)  // dr.IsDBNull(17) ? (DateTime?)null : dr.GetDateTime(17)
                            };
                        }
                    }

                    // Get Result
                    Result = parms[10].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Auth2;
        }

        //
        public MDLAuth Update(MDLAuth Auth, ref string Result)
        {
            // Set up return value
            MDLAuth Auth2 = null;

            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_U", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_STATUS", OracleDbType.Char, 1),
                        new OracleParameter("P_EMPL_ID", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_SYST_ID", OracleDbType.Int32),
                        new OracleParameter("P_ACCT_AREA", OracleDbType.Varchar2, 10),
                        new OracleParameter("P_ACCT_ID", OracleDbType.Varchar2, 255),
                        new OracleParameter("P_ACCT_ROLE", OracleDbType.NVarchar2, 50),
                        new OracleParameter("P_ACTIVE_DATE", OracleDbType.Date),
                        new OracleParameter("P_DEACTIVE_DATE", OracleDbType.Date),
                        new OracleParameter("P_REMARK", OracleDbType.NVarchar2, 200),
                        new OracleParameter("P_UPDATE_USER", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20),
                        new OracleParameter("P_REFCURSOR", OracleDbType.RefCursor)
                    };

                    // Bind Parameter
                    parms[0].Value = Auth.Id;
                    parms[1].Value = Auth.Status.Trim();
                    parms[2].Value = Auth.EmplId.Trim();
                    parms[3].Value = Auth.SystId;
                    parms[4].Value = Auth.AcctArea.Trim();
                    parms[5].Value = Auth.AcctId.Trim();
                    parms[6].Value = Auth.AcctRole.Trim();
                    parms[7].Value = Auth.ActiveDate;
                    parms[8].Value = Auth.DeactiveDate;
                    parms[9].Value = Auth.Remark.Trim();
                    parms[10].Value = Auth.UpdateUser.Trim();
                    parms[11].Direction = ParameterDirection.Output;
                    parms[12].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    using (OracleDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Auth2 = new MDLAuth
                            {
                                Id = dr.GetInt32(0),
                                Status = dr.GetString(1),
                                EmplId = dr.GetString(2),
                                SystId = dr.GetInt32(3),
                                SystCode = dr.GetString(4),
                                AcctArea = dr.GetString(5),
                                AcctId = dr.GetString(6),
                                AcctRole = dr.GetString(7),
                                ActiveDate = dr.GetDateTime(8),
                                DeactiveDate = dr.GetDateTime(9),
                                Remark = dr.IsDBNull(10) ? "" : dr.GetString(10),
                                UpdateTime = dr.GetDateTime(11),
                                UpdateUser = dr.IsDBNull(12) ? "" : dr.GetString(12),
                                EmplName = dr.GetString(13),
                                DeptName = dr.GetString(14),
                                SystName = dr.GetString(15),
                                AuthAnnex = dr.IsDBNull(16) ? "" : dr.GetString(16),
                                AuthProvide = dr.GetDateTime(17)  // dr.IsDBNull(17) ? (DateTime?)null : dr.GetDateTime(17)
                            };
                        }
                    }

                    // Get Result
                    Result = parms[11].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }

            //
            return Auth2;
        }

        //
        public void Delete(int Id, ref string Result)
        {
            // Open Connection
            using (OracleConnection conn = new OracleConnection(OracleHelper.CONN_STRING))
            {
                conn.Open();

                // Create Command
                using (OracleCommand cmd = new OracleCommand("FARS_AUTH_D", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Create Parameter
                    OracleParameter[] parms = new OracleParameter[] {
                        new OracleParameter("P_ID", OracleDbType.Int32),
                        new OracleParameter("P_RESULT", OracleDbType.Varchar2, 20)
                    };

                    // Bind Parameter
                    parms[0].Value = Id;
                    parms[1].Direction = ParameterDirection.Output;

                    // Add Parameter
                    foreach (OracleParameter parm in parms)
                        cmd.Parameters.Add(parm);

                    //
                    cmd.ExecuteNonQuery();

                    // Get Result
                    Result = parms[1].Value.ToString();

                    // Clear Parameter
                    cmd.Parameters.Clear();
                }
            }
        }
    }
}