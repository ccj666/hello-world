﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    public class MDLEmpl
    {
        public string Id { get; set; }
        public string Status { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string ADId { get; set; }
        public Int16 Grade { get; set; }
        public string DeptId { get; set; }
        public string DeptName { get; set; }
        public string JobTitleName { get; set; }
        public DateTime ArriveDate { get; set; }
        public DateTime LeaveDate { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }
    }
}