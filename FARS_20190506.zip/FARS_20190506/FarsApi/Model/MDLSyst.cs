﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    public class MDLSyst
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string Type { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string[] Frequency { get; set; }
        public string ContactName { get; set; }
        public string ContactEmail { get; set; }
        public string ContactTel { get; set; }
        public Int16 DisplayOrder { get; set; }
        public string AuthAnnex { get; set; }
        public DateTime AuthProvide { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }
    }
}