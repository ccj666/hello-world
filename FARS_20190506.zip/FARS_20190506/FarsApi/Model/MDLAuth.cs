﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    /*public class MDLAuth
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string EmplId { get; set; }
        public int SystId { get; set; }
        public string AcctArea { get; set; }
        public string AcctId { get; set; }
        public string AcctRole { get; set; }
        public DateTime ActiveDate { get; set; }
        public DateTime DeactiveDate { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }
    }*/

    public class MDLAuth
    {
        public int Id { get; set; }
        public string Status { get; set; }
        public string EmplId { get; set; }
        public int SystId { get; set; }
        public string SystCode { get; set; }
        public string AcctArea { get; set; }
        public string AcctId { get; set; }
        public string AcctRole { get; set; }
        public DateTime ActiveDate { get; set; }
        public DateTime DeactiveDate { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }
        public string EmplName { get; set; }
        public string DeptName { get; set; }
        public string SystName { get; set; }
        public string AuthAnnex { get; set; }
        public DateTime AuthProvide { get; set; }
    }
}