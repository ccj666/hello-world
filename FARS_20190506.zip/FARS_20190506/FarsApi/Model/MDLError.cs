﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    public class MDLError
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
