﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    /* compare Pool with Auth */
    public class MDLCmpr
    {
        public Int64 Pool_Id { get; set; }
        public string Pool_SystCode { get; set; }
        public string Pool_AcctArea { get; set; }
        public string Pool_AcctId { get; set; }
        public string Pool_AcctRole { get; set; }
        public string Pool_AcctEmail { get; set; }
        public int Pool_SystId { get; set; }
        public string Pool_IsAcctArea { get; set; }
        public string Pool_EmplId { get; set; }
        public string Pool_MappingBy { get; set; }
        public string Pool_IsAcctRole { get; set; }
        public int Auth_Id { get; set; }
        public string Auth_EmplId { get; set; }
        public int Auth_SystId { get; set; }
        public string Auth_SystCode { get; set; }
        public string Auth_AcctArea { get; set; }
        public string Auth_AcctId { get; set; }
        public string Auth_AcctRole { get; set; }
    }
}