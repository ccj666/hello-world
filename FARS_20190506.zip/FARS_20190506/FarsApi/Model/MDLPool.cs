﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FarsApi.Model
{
    public class MDLPool
    {
        public Int64 Id { get; set; }
        public string SystCode { get; set; }
        public string AcctArea { get; set; }
        public string AcctId { get; set; }
        public string AcctRole { get; set; }
        public string AcctEmail { get; set; }
        public int SystId { get; set; }
        public string IsAcctArea { get; set; }
        public string EmplId { get; set; }
        public string MappingBy { get; set; }
        public string IsAcctRole { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdateUser { get; set; }
    }

    public class MDLPool_Add
    {
        public string SystCode { get; set; }
        public string AcctArea { get; set; }
        public string AcctId { get; set; }
        public string AcctRole1 { get; set; }
        public string AcctRole2 { get; set; }
        public string AcctRole3 { get; set; }
        public string UpdateUser { get; set; }
    }
}