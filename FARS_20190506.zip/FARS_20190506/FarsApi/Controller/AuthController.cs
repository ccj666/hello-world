﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;

using FarsApi.Model;
using FarsApi.BLL;

namespace FarsApi.Controller
{
    public class AuthController : ApiController
    {
        // GET: api/Auth/5
        public IHttpActionResult Get(int Id)
        {
            //
            BLLAuth objAuth = new BLLAuth();
            MDLAuth Auth = objAuth.Get(Id);

            //
            if (Auth == null)
            {
                return NotFound();
            }

            return Ok(Auth);
        }

        // GET: api/Auth
        public IHttpActionResult GetByEmplSyst([FromUri] string EmplId, int SystId)
        {
            if (string.IsNullOrEmpty(EmplId))
                EmplId = "";

            //
            BLLAuth objAuth = new BLLAuth();
            ICollection<MDLAuth> AuthList = objAuth.GetByEmplSyst(EmplId, SystId);

            //
            /*if (AuthList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(AuthList);
        }


        // GET: api/Auth
        [HttpGet]
        [Route("Auth/Report/{Frequency}")]
        public IHttpActionResult GetReport(string Frequency)
        {
            //
            BLLAuth objAuth = new BLLAuth();
            ICollection<MDLAuth> AuthList = objAuth.GetReport(Frequency);

            //
            /*if (AuthList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(AuthList);
        }

        // POST: api/Auth
        public IHttpActionResult Post(MDLAuth Auth)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            string Result = "";
            BLLAuth objAuth = new BLLAuth();
            MDLAuth Auth2 = objAuth.Add(Auth, ref Result);

            //
            if (Auth2 == null)  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_AUTH_I 發生錯誤!" };
                if (Result == "AuthExist")
                {
                    Error.Code = Result;
                    Error.Description = "權限設定不得重複!";
                }
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success) return inserted Auth
                return Ok(Auth2);
        }

        // PUT: api/Auth/5
        public IHttpActionResult Put(int Id, MDLAuth Auth)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            string Result = "";
            BLLAuth objAuth = new BLLAuth();
            MDLAuth Auth2 = objAuth.Update(Auth, ref Result);

            //
            if (Auth2 == null)  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_AUTH_U 發生錯誤!" };
                if (Result == "AuthExist")
                {
                    Error.Code = Result;
                    Error.Description = "權限設定不得重複!";
                }
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success) return inserted Auth
                return Ok(Auth2);
        }


        // DELETE: api/Auth/5
        public IHttpActionResult Delete(int Id)
        {
            //
            string Result = "";
            BLLAuth objAuth = new BLLAuth();
            objAuth.Delete(Id, ref Result);

            //
            if (Result != "Success")  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_AUTH_D 發生錯誤!" };
                /*if (Result == "HasAuth")
                {
                    Error.Code = Result;
                    Error.Description = "此系統還有內部權限設定, 不得刪除!";
                }*/
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success)
                return Ok();
        }
    }
}
