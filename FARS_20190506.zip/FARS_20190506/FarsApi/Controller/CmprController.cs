﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using FarsApi.Model;
using FarsApi.BLL;

namespace FarsApi.Controller
{
    public class CmprController : ApiController
    {
        // GET: api/Cmpr
        public IHttpActionResult Get()
        {
            //
            BLLCmpr objCmpr = new BLLCmpr();
            ICollection<MDLCmpr> CmprList = objCmpr.GetAll();

            //
            /*if (CmprList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(CmprList);
        }
    }
}
