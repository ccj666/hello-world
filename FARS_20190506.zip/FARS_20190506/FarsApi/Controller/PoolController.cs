﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using FarsApi.Model;
using FarsApi.BLL;

namespace FarsApi.Controller
{
    public class PoolController : ApiController
    {
        // GET: api/Pool
        public IHttpActionResult Get()
        {
            //
            BLLPool objPool = new BLLPool();
            ICollection<MDLPool> PoolList = objPool.GetAll();

            //
            /*if (PoolList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(PoolList);
        }

        // POST: api/Pool
        public IHttpActionResult Post(MDLPool_Add Pool)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            BLLPool objPool = new BLLPool();
            objPool.Add(Pool);

            //
            return Ok();
        }

        // POST: api/Pool
        [HttpPost]
        [Route("Pool/PostList")]
        public IHttpActionResult PostList(MDLPool_Add[] PoolList)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            BLLPool objPool = new BLLPool();
            foreach (MDLPool_Add Pool in PoolList)
            {
                objPool.Add(Pool);
            }

            //
            return Ok();
        }

        // DELETE: api/Pool/5
        [HttpPost]
        [Route("Pool/DeleteAll")]
        public IHttpActionResult DeleteAll()
        {
            //
            BLLPool objPool = new BLLPool();
            objPool.DeleteAll();

            //
            return Ok();
        }
    }
}
