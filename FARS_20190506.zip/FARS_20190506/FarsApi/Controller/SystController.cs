﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using FarsApi.Model;
using FarsApi.BLL;

namespace FarsApi.Controller
{
    public class SystController : ApiController
    {
        // GET: api/Syst
        public IHttpActionResult Get()
        {
            //
            BLLSyst objSyst = new BLLSyst();
            ICollection<MDLSyst> SystList = objSyst.GetAll();

            //
            /*if (SystList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(SystList);
        }

        // GET: api/Syst
        public IHttpActionResult GetSearch([FromUri] string Search)
        {
            //
            BLLSyst objSyst = new BLLSyst();
            ICollection<MDLSyst> SystList = objSyst.Search(Search);

            //
            /*if (SystList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(SystList);
        }

        // GET: api/Syst/HasAuth
        [HttpGet]
        [Route("Syst/HasAuth/{Frequency}")]
        public IHttpActionResult GetHasAuth(string Frequency)
        {
            //
            BLLSyst objSyst = new BLLSyst();
            ICollection<MDLSyst> SystList = objSyst.GetHasAuth(Frequency);

            //
            /*if (SystList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(SystList);
        }

        // GET: api/Syst/5
        public IHttpActionResult Get(int Id)
        {
            //
            BLLSyst objSyst = new BLLSyst();
            MDLSyst Syst = objSyst.Get(Id);

            //
            if (Syst == null)
            {
                return NotFound();
            }

            return Ok(Syst);
        }

        // POST: api/Syst
        public IHttpActionResult Post(MDLSyst Syst)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            string Result = "";
            BLLSyst objSyst = new BLLSyst();
            MDLSyst Syst2 = objSyst.Add(Syst, ref Result);

            //
            if (Syst2 == null)  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_SYST_I 發生錯誤!" };
                if (Result == "CodeExist")
                {
                    Error.Code = Result;
                    Error.Description = "系統代碼不得重複!";
                }
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success) return inserted Syst
                return Ok(Syst2);
        }

        // PUT: api/Syst/5
        public IHttpActionResult Put(int Id, MDLSyst Syst)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            //
            string Result = "";
            BLLSyst objSyst = new BLLSyst();
            MDLSyst Syst2 = objSyst.Update(Syst, ref Result);

            //
            if (Syst2 == null)  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_SYST_U 發生錯誤!" };
                if (Result == "CodeExist")
                {
                    Error.Code = Result;
                    Error.Description = "系統代碼不得重複!";
                }
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success) return inserted Syst
                return Ok(Syst2);
        }

        // DELETE: api/Syst/5
        public IHttpActionResult Delete(int Id)
        {
            //
            string Result = "";
            BLLSyst objSyst = new BLLSyst();
            objSyst.Delete(Id, ref Result);

            //
            if (Result != "Success")  // (error) return error
            {
                MDLError Error = new MDLError { Code = Result, Description = "FARS_SYST_D 發生錯誤!" };
                if (Result == "HasAuth")
                {
                    Error.Code = Result;
                    Error.Description = "此系統還有內部權限設定, 不得刪除!";
                }
                return Content(HttpStatusCode.BadRequest, Error);
            }
            else  // (success)
                return Ok();
        }
    }
}
