﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;

using FarsApi.Model;
using FarsApi.BLL;

namespace FarsApi.Controller
{
    public class EmplController : ApiController
    {
        // GET: api/Empl
        public IHttpActionResult Get()
        {
            ICollection<MDLEmpl> EmplList = new List<MDLEmpl>();

            // get Empl from database
            using (SqlDataReader dr = SQLHelper.ExecuteReader(SQLHelper.CONN_STRING, CommandType.StoredProcedure, "FARS_EMPL_L", null))
            {
                while (dr.Read())
                {
                    MDLEmpl Empl = new MDLEmpl { Id = dr.GetString(0), Status = dr.GetString(1), Name = dr.GetString(2), Email = dr.GetString(3), ADId = dr.GetString(4), Grade = dr.GetInt16(5), DeptId = dr.GetString(6), DeptName = dr.GetString(7), JobTitleName = dr.GetString(8), ArriveDate = dr.GetDateTime(9), LeaveDate = dr.GetDateTime(10), UpdateTime = dr.GetDateTime(11), UpdateUser = dr.GetString(12) };
                    EmplList.Add(Empl);
                }
            }

            //
            /*if (EmplList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(EmplList);
        }

        // GET: api/Empl
        public IHttpActionResult GetSearch([FromUri] string Search)
        {
            //
            BLLEmpl objEmpl = new BLLEmpl();
            ICollection<MDLEmpl> EmplList = objEmpl.Search(Search);

            //
            /*if (EmplList.Count == 0)
            {
                return NotFound();
            }*/

            return Ok(EmplList);
        }

        // GET: api/Empl/5
        public IHttpActionResult Get(string Id)
        {
            // Set up a return value
            MDLEmpl Empl = null;

            // Create a parameter
            SqlParameter parm = new SqlParameter("@ID", SqlDbType.VarChar, 20);

            // Bind the parameter
            parm.Value = Id;

            // Execute the query
            using (SqlDataReader dr = SQLHelper.ExecuteReader(SQLHelper.CONN_STRING, CommandType.StoredProcedure, "FARS_EMPL_S", parm))
            {
                while (dr.Read())
                {
                    Empl = new MDLEmpl { Id = dr.GetString(0), Status = dr.GetString(1), Name = dr.GetString(2), Email = dr.GetString(3), ADId = dr.GetString(4), Grade = dr.GetInt16(5), DeptId = dr.GetString(6), DeptName = dr.GetString(7), JobTitleName = dr.GetString(8), ArriveDate = dr.GetDateTime(9), LeaveDate = dr.GetDateTime(10), UpdateTime = dr.GetDateTime(11), UpdateUser = dr.GetString(12) };
                }
            }

            if (Empl == null)
            {
                return NotFound();
            }

            return Ok(Empl);
        }

        // POST: api/Empl
        public IHttpActionResult Post(MDLEmpl Empl)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            // Create the parameters
            SqlParameter[] parms = new SqlParameter[] {
                //new SqlParameter("@ID", SqlDbType.VarChar, 20),
                new SqlParameter("@STATUS", SqlDbType.Char, 1),
                new SqlParameter("@NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@EMAIL", SqlDbType.VarChar, 255),
                new SqlParameter("@AD_ID", SqlDbType.VarChar, 20),
                new SqlParameter("@GRADE", SqlDbType.SmallInt),
                new SqlParameter("@DEPT_ID", SqlDbType.VarChar, 20),
                new SqlParameter("@DEPT_NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@JOB_TITLE_NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@ARRIVE_DATE", SqlDbType.DateTime),
                new SqlParameter("@LEAVE_DATE", SqlDbType.DateTime),
                new SqlParameter("@UPDATE_USER", SqlDbType.VarChar, 20)
            };

            // Bind the parameters
            //parms[0].Value = Empl.Id
            parms[0].Value = Empl.Status.Trim();
            parms[1].Value = Empl.Name.Trim();
            parms[2].Value = Empl.Email.Trim();
            parms[3].Value = Empl.ADId.Trim();
            parms[4].Value = Empl.Grade;
            parms[5].Value = Empl.DeptId.Trim();
            parms[6].Value = Empl.DeptName.Trim();
            parms[7].Value = Empl.JobTitleName.Trim();
            parms[8].Value = Empl.ArriveDate;
            parms[9].Value = Empl.LeaveDate;
            parms[10].Value = Empl.UpdateUser;

            // Execute the query
            SQLHelper.ExecuteNonQuery(SQLHelper.CONN_STRING, CommandType.StoredProcedure, "FARS_EMPL_I", parms);

            return Ok();
        }

        // PUT: api/Empl/5
        public IHttpActionResult Put(string Id, MDLEmpl Empl)  // , string TranUser
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid model");

            // Create the parameters
            SqlParameter[] parms = new SqlParameter[] {
                new SqlParameter("@ID", SqlDbType.VarChar, 20),
                new SqlParameter("@STATUS", SqlDbType.Char, 1),
                new SqlParameter("@NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@EMAIL", SqlDbType.VarChar, 255),
                new SqlParameter("@AD_ID", SqlDbType.VarChar, 20),
                new SqlParameter("@GRADE", SqlDbType.SmallInt),
                new SqlParameter("@DEPT_ID", SqlDbType.VarChar, 20),
                new SqlParameter("@DEPT_NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@JOB_TITLE_NAME", SqlDbType.NVarChar, 50),
                new SqlParameter("@ARRIVE_DATE", SqlDbType.DateTime),
                new SqlParameter("@LEAVE_DATE", SqlDbType.DateTime),
                new SqlParameter("@UPDATE_USER", SqlDbType.VarChar, 20)
            };

            // Bind the parameters
            parms[0].Value = Empl.Id;  // Id
            parms[1].Value = Empl.Status;
            parms[2].Value = Empl.Name;
            parms[3].Value = Empl.Email;
            parms[4].Value = Empl.ADId;
            parms[5].Value = Empl.Grade;
            parms[6].Value = Empl.DeptId;
            parms[7].Value = Empl.DeptName;
            parms[8].Value = Empl.JobTitleName;
            parms[9].Value = Empl.ArriveDate;
            parms[10].Value = Empl.LeaveDate;
            parms[11].Value = Empl.UpdateUser;

            // Execute the query
            SQLHelper.ExecuteNonQuery(SQLHelper.CONN_STRING, CommandType.StoredProcedure, "FARS_EMPL_U", parms);

            return Ok();
        }

        // DELETE: api/Empl/5
        public IHttpActionResult Delete(string Id)
        {
            // Create the parameters
            SqlParameter[] parms = new SqlParameter[] {
                new SqlParameter("@ID", SqlDbType.VarChar, 20),
                new SqlParameter("@RESULT", SqlDbType.VarChar, 20)
            };

            // Bind the parameters
            parms[0].Value = Id;
            parms[1].Value = ParameterDirection.Output;

            // Execute the query
            SQLHelper.ExecuteNonQuery(SQLHelper.CONN_STRING, CommandType.StoredProcedure, "FARS_EMPL_D", parms);

            return Ok();
        }
    }
}
